# 股票智能分析 - Android 版

基于 AI 大模型的股票智能分析系统的 Android 客户端实现。

## 功能特性

- **AI 智能分析**：基于 GPT/Gemini/Claude 等大模型的股票分析
- **实时行情**：支持 A股、港股、美股的实时行情查看
- **技术分析**：K线图、均线、MACD、RSI 等技术指标
- **自选股管理**：添加/删除自选股，批量分析
- **大盘复盘**：市场指数、涨跌统计、板块表现
- **推送通知**：定时推送每日分析结果
- **历史记录**：查看过往分析记录

## 技术栈

- **语言**：Kotlin
- **架构**：MVVM + Repository Pattern
- **依赖注入**：Hilt
- **网络**：Retrofit + OkHttp
- **本地存储**：Room
- **异步**：Kotlin Coroutines + Flow
- **后台任务**：WorkManager
- **UI**：Jetpack Compose / ViewBinding + Material Design 3

## 项目结构

```
app/src/main/java/com/example/stockanalysis/
├── data/
│   ├── api/           # API 接口定义
│   ├── local/         # 本地数据库 (Room)
│   ├── model/         # 数据模型
│   └── repository/    # 数据仓库
├── di/                # 依赖注入模块
├── notification/      # 通知相关
├── ui/                # UI 层
│   ├── MainActivity.kt
│   ├── HomeFragment.kt
│   ├── WatchlistFragment.kt
│   ├── AnalysisFragment.kt
│   ├── HistoryFragment.kt
│   ├── StockDetailActivity.kt
│   ├── AnalysisResultActivity.kt
│   ├── SettingsActivity.kt
│   └── viewmodel/     # ViewModels
├── utils/             # 工具类
└── StockAnalysisApplication.kt
```

## 环境要求

- Android Studio Hedgehog (2023.1.1) 或更高版本
- JDK 17
- Android SDK 34
- Gradle 8.2

## 构建说明

### 1. 克隆项目

```bash
cd /Users/chunlin5/opensource/stock-analysis/android/StockAnalysisApp
```

### 2. 配置 API 密钥

在 `local.properties` 文件中添加你的 API 密钥：

```properties
OPENAI_API_KEY=your_openai_api_key_here
GEMINI_API_KEY=your_gemini_api_key_here
```

### 3. 构建 APK

```bash
./gradlew assembleDebug
```

构建完成后，APK 文件位于：
`app/build/outputs/apk/debug/app-debug.apk`

### 4. 构建 Release 版本

```bash
./gradlew assembleRelease
```

## 部署到设备

### 方法一：使用 Android Studio

1. 打开 Android Studio
2. 选择 "Open an existing project"
3. 选择 `StockAnalysisApp` 文件夹
4. 连接设备或启动模拟器
5. 点击运行按钮 (▶)

### 方法二：使用 ADB 命令行

```bash
# 安装 Debug 版本
adb install app/build/outputs/apk/debug/app-debug.apk

# 或者安装 Release 版本
adb install app/build/outputs/apk/release/app-release-unsigned.apk
```

### 方法三：使用构建脚本

```bash
# 构建并安装到已连接的设备
./build-and-install.sh
```

## 配置说明

### AI 模型配置

在应用的「设置」页面中配置：

1. **AI 提供商**：OpenAI / Google Gemini / Anthropic Claude / DeepSeek / 自定义
2. **API Key**：对应的 API 密钥
3. **模型名称**：如 `gpt-3.5-turbo`, `gemini-pro` 等
4. **Base URL**：API 基础地址（使用自定义提供商时需要）

### 通知设置

- **启用推送**：开启/关闭每日分析推送
- **推送时间**：设置每日推送时间（默认 18:00）
- **自动分析**：是否在后台自动执行分析

## 数据来源

本项目支持多种数据源：

- **AkShare**：A股数据（需要网络连接）
- **Tushare**：专业金融数据（需要 Token）
- **YFinance**：美股数据
- **新浪财经**：实时行情

## 许可证

MIT License

## 免责声明

本应用仅供学习和研究使用，不构成任何投资建议。股市有风险，投资需谨慎。
