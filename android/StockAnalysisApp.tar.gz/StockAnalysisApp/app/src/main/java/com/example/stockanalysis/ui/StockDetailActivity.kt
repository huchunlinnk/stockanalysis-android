package com.example.stockanalysis.ui

import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.stockanalysis.databinding.ActivityStockDetailBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * 股票详情页面
 * 显示股票基本信息、实时行情和技术指标
 */
@AndroidEntryPoint
class StockDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStockDetailBinding
    private val viewModel: StockDetailViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStockDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val symbol = intent.getStringExtra(EXTRA_SYMBOL) ?: ""
        val name = intent.getStringExtra(EXTRA_NAME) ?: ""

        if (symbol.isEmpty()) {
            Toast.makeText(this, "股票代码无效", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        initViews(name, symbol)
        observeViewModel()
        viewModel.loadStockDetail(symbol, name)
    }

    private fun initViews(name: String, symbol: String) {
        // 设置Toolbar
        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            title = name
            subtitle = symbol
        }

        // 分析按钮
        binding.btnAnalyze?.setOnClickListener {
            viewModel.startAnalysis()
        }

        // 添加到自选按钮
        binding.btnWatch?.setOnClickListener {
            viewModel.addToWatchlist()
        }

        // 刷新按钮
        binding.btnTrade?.setOnClickListener {
            viewModel.refreshData()
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.stockQuote.collectLatest { quote ->
                        quote?.let { updateQuoteUI(it) }
                    }
                }

                launch {
                    viewModel.technicalIndicators.collectLatest { indicators ->
                        indicators?.let { updateTechnicalUI(it) }
                    }
                }

                launch {
                    viewModel.isLoading.collectLatest { isLoading ->
                        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
                    }
                }

                launch {
                    viewModel.errorMessage.collectLatest { error ->
                        error?.let {
                            Toast.makeText(this@StockDetailActivity, it, Toast.LENGTH_SHORT).show()
                        }
                    }
                }

                launch {
                    viewModel.isInWatchlist.collectLatest { isInWatchlist ->
                        binding.btnWatch?.text = if (isInWatchlist) "已在自选" else "加入自选"
                        binding.btnWatch?.isEnabled = !isInWatchlist
                    }
                }

                launch {
                    viewModel.navigationEvent.collectLatest { event ->
                        when (event) {
                            is StockDetailViewModel.NavigationEvent.ToAnalysisResult -> {
                                openAnalysisResult(event.analysisId)
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * 更新行情UI
     */
    private fun updateQuoteUI(quote: com.example.stockanalysis.data.model.StockQuote) {
        binding.tvCurrentPrice.text = quote.getPriceText()
        binding.tvChange.text = quote.getChangePercentText()
        binding.tvChangeValue.text = "${if (quote.change >= 0) "+" else ""}${String.format("%.2f", quote.change)}"

        // 涨跌颜色
        val colorRes = when {
            quote.change > 0 -> android.R.color.holo_red_dark
            quote.change < 0 -> android.R.color.holo_green_dark
            else -> android.R.color.darker_gray
        }
        val color = getColor(colorRes)
        binding.tvCurrentPrice.setTextColor(color)
        binding.tvChange.setTextColor(color)
        binding.tvChangeValue.setTextColor(color)

        // 详细数据
        binding.tvOpen.text = String.format("%.2f", quote.openPrice)
        binding.tvHigh.text = String.format("%.2f", quote.highPrice)
        binding.tvLow.text = String.format("%.2f", quote.lowPrice)
        binding.tvPrevClose.text = String.format("%.2f", quote.prevClose)
        binding.tvVolume.text = formatVolume(quote.volume)
        binding.tvTurnover.text = quote.turnover?.let { formatTurnover(it) } ?: "--"
        binding.tvUpdateTime.text = "更新时间: ${formatTime(quote.updateTime)}"

        // 扩展字段
        quote.peRatio?.let { binding.tvPe.text = String.format("%.2f", it) }
        quote.pbRatio?.let { binding.tvPb.text = String.format("%.2f", it) }
        quote.marketCap?.let { binding.tvMarketCap.text = formatMarketCap(it) }
        quote.turnoverRate?.let { binding.tvTurnoverRate.text = "${String.format("%.2f", it)}%" }
    }

    /**
     * 更新技术指标UI
     */
    private fun updateTechnicalUI(indicators: com.example.stockanalysis.data.model.TechnicalIndicators) {
        indicators.ma5?.let { binding.tvMa5.text = String.format("%.2f", it) }
        indicators.ma10?.let { binding.tvMa10.text = String.format("%.2f", it) }
        indicators.ma20?.let { binding.tvMa20.text = String.format("%.2f", it) }
        indicators.ma60?.let { binding.tvMa60.text = String.format("%.2f", it) }
        indicators.rsi?.let { binding.tvRsi.text = String.format("%.2f", it) }

        indicators.macd?.let { macd ->
            binding.tvMacdDif.text = String.format("%.3f", macd.dif)
            binding.tvMacdDea.text = String.format("%.3f", macd.dea)
            binding.tvMacdBar.text = String.format("%.3f", macd.macd)
        }

        indicators.kdj?.let { kdj ->
            binding.tvKdjK.text = String.format("%.2f", kdj.k)
            binding.tvKdjD.text = String.format("%.2f", kdj.d)
            binding.tvKdjJ.text = String.format("%.2f", kdj.j)
        }

        indicators.boll?.let { boll ->
            binding.tvBollUpper.text = String.format("%.2f", boll.upper)
            binding.tvBollMiddle.text = String.format("%.2f", boll.middle)
            binding.tvBollLower.text = String.format("%.2f", boll.lower)
        }
    }

    private fun formatVolume(volume: Long): String {
        return when {
            volume >= 100000000 -> "${String.format("%.2f", volume / 100000000.0)}亿"
            volume >= 10000 -> "${String.format("%.2f", volume / 10000.0)}万"
            else -> volume.toString()
        }
    }

    private fun formatTurnover(turnover: Double): String {
        return when {
            turnover >= 100000000 -> "${String.format("%.2f", turnover / 100000000.0)}亿"
            turnover >= 10000 -> "${String.format("%.2f", turnover / 10000.0)}万"
            else -> String.format("%.2f", turnover)
        }
    }

    private fun formatMarketCap(cap: Double): String {
        return when {
            cap >= 100000000000 -> "${String.format("%.2f", cap / 100000000000.0)}万亿"
            cap >= 100000000 -> "${String.format("%.2f", cap / 100000000.0)}亿"
            else -> String.format("%.2f", cap)
        }
    }

    private fun formatTime(date: java.util.Date): String {
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        return sdf.format(date)
    }

    private fun openAnalysisResult(analysisId: String) {
        val intent = Intent(this, AnalysisResultActivity::class.java).apply {
            putExtra(AnalysisResultActivity.EXTRA_ANALYSIS_ID, analysisId)
        }
        startActivity(intent)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    companion object {
        const val EXTRA_SYMBOL = "extra_symbol"
        const val EXTRA_NAME = "extra_name"
    }
}
