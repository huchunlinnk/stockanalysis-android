package com.example.stockanalysis.di

import com.example.stockanalysis.data.api.LLMApiService
import com.example.stockanalysis.data.api.StockApiService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Named
import javax.inject.Singleton

/**
 * 网络模块 - 提供 Retrofit 客户端
 */
@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    /**
     * 提供 OkHttpClient
     */
    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
        
        return OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    /**
     * 提供股票数据 API
     */
    @Provides
    @Singleton
    @Named("stockApi")
    fun provideStockRetrofit(okHttpClient: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl("https://mock-api.example.com/")
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    /**
     * 提供股票 API 服务
     */
    @Provides
    @Singleton
    fun provideStockApiService(@Named("stockApi") retrofit: Retrofit): StockApiService {
        return retrofit.create(StockApiService::class.java)
    }

    /**
     * 提供 LLM API
     */
    @Provides
    @Singleton
    @Named("llmApi")
    fun provideLLMRetrofit(okHttpClient: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl("https://api.openai.com/")
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    /**
     * 提供 LLM API 服务
     */
    @Provides
    @Singleton
    fun provideLLMApiService(@Named("llmApi") retrofit: Retrofit): LLMApiService {
        return retrofit.create(LLMApiService::class.java)
    }
}
