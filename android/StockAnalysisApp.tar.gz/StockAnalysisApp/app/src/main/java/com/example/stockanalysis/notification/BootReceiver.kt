package com.example.stockanalysis.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * 开机广播接收器
 * 设备重启后重新设置定时分析任务
 */
@AndroidEntryPoint
class BootReceiver : BroadcastReceiver() {

    @Inject
    lateinit var notificationScheduler: NotificationScheduler

    companion object {
        private const val TAG = "BootReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            "android.intent.action.QUICKBOOT_POWERON" -> {
                Log.d(TAG, "Received boot/restart broadcast: ${intent.action}")
                
                // 重新设置通知调度器
                try {
                    notificationScheduler.rescheduleAllTasks()
                    Log.d(TAG, "Successfully rescheduled all tasks after boot")
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to reschedule tasks after boot", e)
                }
            }
        }
    }
}
