package com.example.stockanalysis.notification

import android.content.Context
import android.util.Log
import androidx.hilt.work.HiltWorker
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.stockanalysis.data.model.AnalysisResult
import com.example.stockanalysis.data.repository.StockRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * 后台分析工作器
 * 使用 WorkManager 执行定时股票分析任务
 */
@HiltWorker
class AnalysisWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val stockRepository: StockRepository,
    private val notificationHelper: NotificationHelper
) : CoroutineWorker(context, params) {

    companion object {
        private const val TAG = "AnalysisWorker"
        
        // Work 名称
        const val WORK_NAME_DAILY_ANALYSIS = "daily_stock_analysis"
        const val WORK_NAME_CUSTOM_ANALYSIS = "custom_stock_analysis"
        
        // 输入参数键
        const val KEY_STOCK_SYMBOL = "stock_symbol"
        const val KEY_STOCK_NAME = "stock_name"
        const val KEY_ANALYSIS_TYPE = "analysis_type"
        
        // 分析类型
        const val ANALYSIS_TYPE_DAILY = "daily"
        const val ANALYSIS_TYPE_CUSTOM = "custom"
        const val ANALYSIS_TYPE_WATCHLIST = "watchlist"

        /**
         * 创建每日分析任务（每天早上 9:30 执行）
         */
        fun scheduleDailyAnalysis(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .setRequiresBatteryNotLow(true)
                .build()

            // 计算到下一个 9:30 的延迟时间
            val initialDelay = calculateInitialDelay(9, 30)

            val dailyWorkRequest = PeriodicWorkRequestBuilder<AnalysisWorker>(
                24, TimeUnit.HOURS
            )
                .setConstraints(constraints)
                .setInitialDelay(initialDelay, TimeUnit.MILLISECONDS)
                .setInputData(
                    workDataOf(
                        KEY_ANALYSIS_TYPE to ANALYSIS_TYPE_DAILY
                    )
                )
                .setBackoffCriteria(
                    BackoffPolicy.EXPONENTIAL,
                    WorkRequest.MIN_BACKOFF_MILLIS,
                    TimeUnit.MILLISECONDS
                )
                .addTag(WORK_NAME_DAILY_ANALYSIS)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME_DAILY_ANALYSIS,
                ExistingPeriodicWorkPolicy.KEEP,
                dailyWorkRequest
            )

            Log.d(TAG, "Scheduled daily analysis work, initial delay: ${initialDelay}ms")
        }

        /**
         * 创建自定义股票分析任务
         */
        fun scheduleCustomAnalysis(
            context: Context,
            stockSymbol: String,
            stockName: String,
            intervalHours: Long = 4
        ) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val customWorkRequest = PeriodicWorkRequestBuilder<AnalysisWorker>(
                intervalHours, TimeUnit.HOURS
            )
                .setConstraints(constraints)
                .setInputData(
                    workDataOf(
                        KEY_STOCK_SYMBOL to stockSymbol,
                        KEY_STOCK_NAME to stockName,
                        KEY_ANALYSIS_TYPE to ANALYSIS_TYPE_CUSTOM
                    )
                )
                .addTag(WORK_NAME_CUSTOM_ANALYSIS)
                .addTag("stock_$stockSymbol")
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "${WORK_NAME_CUSTOM_ANALYSIS}_$stockSymbol",
                ExistingPeriodicWorkPolicy.KEEP,
                customWorkRequest
            )

            Log.d(TAG, "Scheduled custom analysis for $stockName ($stockSymbol)")
        }

        /**
         * 取消所有分析任务
         */
        fun cancelAllAnalysis(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME_DAILY_ANALYSIS)
            WorkManager.getInstance(context).cancelAllWorkByTag(WORK_NAME_CUSTOM_ANALYSIS)
            Log.d(TAG, "Cancelled all analysis work")
        }

        /**
         * 取消特定股票的分析任务
         */
        fun cancelAnalysisForStock(context: Context, stockSymbol: String) {
            WorkManager.getInstance(context).cancelUniqueWork(
                "${WORK_NAME_CUSTOM_ANALYSIS}_$stockSymbol"
            )
            Log.d(TAG, "Cancelled analysis work for $stockSymbol")
        }

        /**
         * 计算到下一个指定时间的延迟（毫秒）
         */
        private fun calculateInitialDelay(targetHour: Int, targetMinute: Int): Long {
            val currentTime = Calendar.getInstance()
            val targetTime = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, targetHour)
                set(Calendar.MINUTE, targetMinute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }

            // 如果目标时间已过，设置为明天
            if (targetTime.before(currentTime)) {
                targetTime.add(Calendar.DAY_OF_YEAR, 1)
            }

            return targetTime.timeInMillis - currentTime.timeInMillis
        }
    }

    override suspend fun doWork(): Result {
        Log.d(TAG, "Starting analysis work")

        return try {
            val analysisType = inputData.getString(KEY_ANALYSIS_TYPE) ?: ANALYSIS_TYPE_DAILY
            
            when (analysisType) {
                ANALYSIS_TYPE_DAILY -> performDailyAnalysis()
                ANALYSIS_TYPE_CUSTOM -> performCustomAnalysis()
                ANALYSIS_TYPE_WATCHLIST -> performWatchlistAnalysis()
                else -> performDailyAnalysis()
            }

            Log.d(TAG, "Analysis work completed successfully")
            Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "Analysis work failed", e)
            // 根据错误类型决定是重试还是失败
            if (runAttemptCount < 3) {
                Result.retry()
            } else {
                Result.failure(
                    workDataOf("error" to (e.message ?: "Unknown error"))
                )
            }
        }
    }

    /**
     * 执行每日分析
     */
    private suspend fun performDailyAnalysis() {
        Log.d(TAG, "Performing daily analysis")
        
        // 获取用户关注的股票列表
        val watchlist = stockRepository.getWatchlist()
        
        if (watchlist.isEmpty()) {
            notificationHelper.sendDailyReminderNotification(
                "您还没有关注的股票，添加股票以获取每日分析"
            )
            return
        }

        // 对每只股票进行分析
        var hasSignificantChange = false
        val analysisResults = mutableListOf<AnalysisResult>()

        watchlist.forEach { stock ->
            try {
                val result = stockRepository.analyzeStock(stock.symbol)
                analysisResults.add(result)
                
                // 如果有重要变化，发送通知
                if (result.confidence > 0.8 || result.riskLevel == AnalysisResult.RISK_LEVEL_HIGH) {
                    hasSignificantChange = true
                    notificationHelper.sendAnalysisResultNotification(
                        stockName = stock.name,
                        analysisResult = result.summary,
                        recommendation = result.recommendation
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to analyze ${stock.symbol}", e)
            }
        }

        // 如果没有重要变化，发送汇总提醒
        if (!hasSignificantChange) {
            notificationHelper.sendDailyReminderNotification(
                "今日已分析 ${watchlist.size} 只股票，市场波动正常"
            )
        }
    }

    /**
     * 执行自定义股票分析
     */
    private suspend fun performCustomAnalysis() {
        val symbol = inputData.getString(KEY_STOCK_SYMBOL) ?: return
        val name = inputData.getString(KEY_STOCK_NAME) ?: symbol

        Log.d(TAG, "Performing custom analysis for $name ($symbol)")

        val result = stockRepository.analyzeStock(symbol)
        
        notificationHelper.sendAnalysisResultNotification(
            stockName = name,
            analysisResult = result.summary,
            recommendation = result.recommendation
        )
    }

    /**
     * 执行关注列表分析
     */
    private suspend fun performWatchlistAnalysis() {
        Log.d(TAG, "Performing watchlist analysis")
        
        val watchlist = stockRepository.getWatchlist()
        
        // 获取市场概览
        val marketOverview = stockRepository.getMarketOverview()
        
        notificationHelper.sendDailyReminderNotification(
            "市场概览: ${marketOverview.summary}"
        )
    }
}

/**
 * WorkManager 相关的数据类扩展
 */
private typealias WorkRequest = androidx.work.WorkRequest
