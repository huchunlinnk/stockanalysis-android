package com.example.stockanalysis.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.stockanalysis.MainActivity
import com.example.stockanalysis.R
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 通知帮助类
 * 负责创建通知渠道、发送通知等操作
 * 兼容 Android 13+ 的通知权限管理
 */
@Singleton
class NotificationHelper @Inject constructor(
    @ApplicationContext private val context: Context
) {

    companion object {
        const val CHANNEL_ID_STOCK_ANALYSIS = "stock_analysis_channel"
        const val CHANNEL_ID_SYSTEM = "system_channel"
        const val CHANNEL_NAME_STOCK_ANALYSIS = "股票分析通知"
        const val CHANNEL_NAME_SYSTEM = "系统通知"
        const val CHANNEL_DESCRIPTION_STOCK_ANALYSIS = "显示股票分析结果和重要提醒"
        const val CHANNEL_DESCRIPTION_SYSTEM = "系统相关通知"
        
        const val NOTIFICATION_ID_ANALYSIS_RESULT = 1001
        const val NOTIFICATION_ID_DAILY_REMINDER = 1002
        const val NOTIFICATION_ID_SYSTEM_MESSAGE = 1003
    }

    init {
        createNotificationChannels()
    }

    /**
     * 创建通知渠道（Android O 及以上需要）
     */
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channels = listOf(
                NotificationChannel(
                    CHANNEL_ID_STOCK_ANALYSIS,
                    CHANNEL_NAME_STOCK_ANALYSIS,
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = CHANNEL_DESCRIPTION_STOCK_ANALYSIS
                    enableLights(true)
                    enableVibration(true)
                },
                NotificationChannel(
                    CHANNEL_ID_SYSTEM,
                    CHANNEL_NAME_SYSTEM,
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = CHANNEL_DESCRIPTION_SYSTEM
                }
            )

            val notificationManager = context.getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannels(channels)
        }
    }

    /**
     * 检查是否有发送通知的权限（Android 13+）
     */
    fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    /**
     * 发送股票分析结果通知
     */
    fun sendAnalysisResultNotification(
        stockName: String,
        analysisResult: String,
        recommendation: String
    ) {
        if (!hasNotificationPermission()) {
            return
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("navigate_to", "analysis_result")
            putExtra("stock_name", stockName)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID_STOCK_ANALYSIS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("股票分析完成: $stockName")
            .setContentText(analysisResult)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("$analysisResult\n建议: $recommendation")
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_RECOMMENDATION)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        NotificationManagerCompat.from(context)
            .notify(NOTIFICATION_ID_ANALYSIS_RESULT, notification)
    }

    /**
     * 发送每日提醒通知
     */
    fun sendDailyReminderNotification(message: String = "今日股票分析已准备好，点击查看详情") {
        if (!hasNotificationPermission()) {
            return
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("navigate_to", "daily_analysis")
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            1,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID_STOCK_ANALYSIS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("每日股票分析提醒")
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        NotificationManagerCompat.from(context)
            .notify(NOTIFICATION_ID_DAILY_REMINDER, notification)
    }

    /**
     * 发送系统消息通知
     */
    fun sendSystemNotification(title: String, message: String) {
        if (!hasNotificationPermission()) {
            return
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            2,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID_SYSTEM)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        NotificationManagerCompat.from(context)
            .notify(NOTIFICATION_ID_SYSTEM_MESSAGE, notification)
    }

    /**
     * 取消指定 ID 的通知
     */
    fun cancelNotification(notificationId: Int) {
        NotificationManagerCompat.from(context).cancel(notificationId)
    }

    /**
     * 取消所有通知
     */
    fun cancelAllNotifications() {
        NotificationManagerCompat.from(context).cancelAll()
    }
}
