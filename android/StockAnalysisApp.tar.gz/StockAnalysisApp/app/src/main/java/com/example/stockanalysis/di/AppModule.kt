package com.example.stockanalysis.di

import android.content.Context
import com.example.stockanalysis.data.api.LLMApiService
import com.example.stockanalysis.data.api.StockApiService
import com.example.stockanalysis.data.local.AnalysisResultDao
import com.example.stockanalysis.data.local.StockDao
import com.example.stockanalysis.data.repository.*
import com.example.stockanalysis.utils.SettingsManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * 应用模块
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideSettingsManager(@ApplicationContext context: Context): SettingsManager {
        return SettingsManager(context)
    }

    @Provides
    @Singleton
    fun provideStockRepository(
        stockDao: StockDao,
        stockApiService: StockApiService
    ): StockRepository {
        return StockRepositoryImpl(stockDao, stockApiService)
    }

    @Provides
    @Singleton
    fun provideAnalysisRepository(
        analysisResultDao: AnalysisResultDao,
        llmApiService: LLMApiService,
        stockRepository: StockRepository
    ): AnalysisRepository {
        return AnalysisRepositoryImpl(analysisResultDao, llmApiService, stockRepository)
    }

    @Provides
    @Singleton
    fun provideMarketRepository(
        stockApiService: StockApiService
    ): MarketRepository {
        return MarketRepositoryImpl(stockApiService)
    }
}
