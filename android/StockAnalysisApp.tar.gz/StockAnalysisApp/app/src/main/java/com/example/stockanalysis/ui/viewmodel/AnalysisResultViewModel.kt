package com.example.stockanalysis.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.stockanalysis.data.model.AnalysisResult
import com.example.stockanalysis.data.repository.AnalysisRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * 分析结果ViewModel
 */
@HiltViewModel
class AnalysisResultViewModel @Inject constructor(
    private val analysisRepository: AnalysisRepository
) : ViewModel() {

    private val _analysisResult = MutableStateFlow<AnalysisResult?>(null)
    val analysisResult: StateFlow<AnalysisResult?> = _analysisResult

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage

    private val _shareEvent = MutableSharedFlow<ShareEvent>()
    val shareEvent: SharedFlow<ShareEvent> = _shareEvent

    /**
     * 加载分析结果
     */
    fun loadAnalysisResult(analysisId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            val result = analysisRepository.getResultById(analysisId)
            if (result != null) {
                _analysisResult.value = result
            } else {
                _errorMessage.value = "分析结果不存在"
            }
            _isLoading.value = false
        }
    }

    /**
     * 开始新分析
     */
    fun startNewAnalysis(symbol: String, name: String) {
        viewModelScope.launch {
            _isLoading.value = true
            analysisRepository.analyzeStock(symbol, name).collect { state ->
                when (state) {
                    is com.example.stockanalysis.data.repository.AnalysisState.Loading -> {
                        _isLoading.value = true
                    }
                    is com.example.stockanalysis.data.repository.AnalysisState.Progress -> {
                        // 显示进度
                    }
                    is com.example.stockanalysis.data.repository.AnalysisState.Success -> {
                        _isLoading.value = false
                        _analysisResult.value = state.result
                    }
                    is com.example.stockanalysis.data.repository.AnalysisState.Error -> {
                        _isLoading.value = false
                        _errorMessage.value = state.message
                    }
                }
            }
        }
    }

    /**
     * 分享分析结果
     */
    fun shareResult() {
        viewModelScope.launch {
            _analysisResult.value?.let { result ->
                val content = buildShareContent(result)
                _shareEvent.emit(ShareEvent.Success(content))
            }
        }
    }

    /**
     * 刷新分析
     */
    fun refreshAnalysis() {
        _analysisResult.value?.let { result ->
            startNewAnalysis(result.stockSymbol, result.stockName)
        }
    }

    /**
     * 删除分析结果
     */
    fun deleteAnalysisResult() {
        viewModelScope.launch {
            _analysisResult.value?.let { result ->
                analysisRepository.deleteResult(result.id)
            }
        }
    }

    private fun buildShareContent(result: AnalysisResult): String {
        return """
            📊 ${result.stockName}(${result.stockSymbol}) 分析报告
            
            ⏰ 分析时间: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(result.analysisTime)}
            
            🎯 决策建议: ${result.decision.name}
            
            📈 综合评分: ${result.score}/100
            
            📝 分析摘要:
            ${result.summary}
            
            ⚠️ 免责声明: 本分析仅供参考，不构成投资建议
        """.trimIndent()
    }

    sealed class ShareEvent {
        data class Success(val content: String) : ShareEvent()
    }
}
