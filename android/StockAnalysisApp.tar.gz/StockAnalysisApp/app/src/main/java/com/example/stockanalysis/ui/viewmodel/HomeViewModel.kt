package com.example.stockanalysis.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.stockanalysis.data.model.MarketOverview
import com.example.stockanalysis.data.model.Stock
import com.example.stockanalysis.data.repository.MarketRepository
import com.example.stockanalysis.data.repository.StockRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * 首页ViewModel
 * 管理首页的数据和状态
 */
@HiltViewModel
class HomeViewModel @Inject constructor(
    private val marketRepository: MarketRepository,
    private val stockRepository: StockRepository
) : ViewModel() {

    private val _marketOverview = MutableStateFlow<MarketOverview?>(null)
    val marketOverview: StateFlow<MarketOverview?> = _marketOverview

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage

    private val _searchResults = MutableStateFlow<List<Stock>>(emptyList())
    val searchResults: StateFlow<List<Stock>> = _searchResults

    /**
     * 加载市场概览数据
     */
    fun loadMarketOverview() {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            
            try {
                val result = marketRepository.getMarketOverview()
                result.onSuccess { overview ->
                    _marketOverview.value = overview
                }.onFailure { error ->
                    _errorMessage.value = "加载失败: ${error.message}"
                }
            } catch (e: Exception) {
                _errorMessage.value = "网络错误: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * 搜索股票
     */
    fun searchStocks(query: String) {
        viewModelScope.launch {
            stockRepository.searchStocks(query).collect { results ->
                _searchResults.value = results
            }
        }
    }
}
