package com.example.stockanalysis.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * 通知广播接收器
 * 接收闹钟触发和系统广播，发送相应的通知
 */
@AndroidEntryPoint
class NotificationBroadcastReceiver : BroadcastReceiver() {

    @Inject
    lateinit var notificationHelper: NotificationHelper

    companion object {
        private const val TAG = "NotificationReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        Log.d(TAG, "Received broadcast: ${intent.action}")

        when (intent.action) {
            NotificationScheduler.ACTION_DAILY_REMINDER -> {
                handleDailyReminder()
            }
            NotificationScheduler.ACTION_MARKET_OPEN -> {
                handleMarketOpen()
            }
            NotificationScheduler.ACTION_MARKET_CLOSE -> {
                handleMarketClose()
            }
        }
    }

    /**
     * 处理每日提醒
     */
    private fun handleDailyReminder() {
        Log.d(TAG, "Handling daily reminder")
        notificationHelper.sendDailyReminderNotification(
            "今日股票分析已准备好，点击查看详情"
        )
    }

    /**
     * 处理开盘提醒
     */
    private fun handleMarketOpen() {
        Log.d(TAG, "Handling market open notification")
        notificationHelper.sendSystemNotification(
            title = "股市开盘",
            message = "A股市场已开盘，祝您交易顺利！"
        )
    }

    /**
     * 处理收盘提醒
     */
    private fun handleMarketClose() {
        Log.d(TAG, "Handling market close notification")
        notificationHelper.sendSystemNotification(
            title = "股市收盘",
            message = "A股市场已收盘，查看今日分析总结"
        )
    }
}
