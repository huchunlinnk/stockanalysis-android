package com.example.stockanalysis.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.stockanalysis.data.model.Stock
import com.example.stockanalysis.databinding.FragmentAnalysisBinding
import com.example.stockanalysis.ui.viewmodel.AnalysisViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * 分析Fragment
 * 执行AI分析，支持批量分析和单个股票分析
 */
@AndroidEntryPoint
class AnalysisFragment : Fragment() {

    private var _binding: FragmentAnalysisBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AnalysisViewModel by activityViewModels()

    private lateinit var selectedStockAdapter: SelectedStockAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAnalysisBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews()
        observeViewModel()
        viewModel.loadWatchlist()
    }

    private fun initViews() {
        // 初始化已选股票列表
        selectedStockAdapter = SelectedStockAdapter { stock ->
            viewModel.removeSelectedStock(stock)
        }
        binding.rvSelectedStocks.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = selectedStockAdapter
        }

        // 添加股票按钮
        binding.btnAddStock.setOnClickListener {
            showStockSelectionDialog()
        }

        // 开始分析按钮
        binding.btnStartAnalysis.setOnClickListener {
            viewModel.startAnalysis()
        }

        // 清空选择按钮
        binding.btnClearSelection.setOnClickListener {
            viewModel.clearSelection()
        }
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.watchlist.collectLatest { stocks ->
                        // 更新可选股票列表
                    }
                }

                launch {
                    viewModel.selectedStocks.collectLatest { stocks ->
                        selectedStockAdapter.submitList(stocks)
                        updateUIState(stocks)
                    }
                }

                launch {
                    viewModel.analysisState.collectLatest { state ->
                        updateAnalysisState(state)
                    }
                }

                launch {
                    viewModel.isLoading.collectLatest { isLoading ->
                        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
                        binding.btnStartAnalysis.isEnabled = !isLoading
                    }
                }

                launch {
                    viewModel.errorMessage.collectLatest { error ->
                        error?.let {
                            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
                        }
                    }
                }

                launch {
                    viewModel.navigationEvent.collectLatest { event ->
                        when (event) {
                            is AnalysisViewModel.NavigationEvent.ToResult -> {
                                (activity as? MainActivity)?.openAnalysisResult(event.analysisId)
                            }
                            is AnalysisViewModel.NavigationEvent.ToBatchResult -> {
                                // 打开批量分析结果页面
                                Toast.makeText(context, "批量分析完成，共 ${event.count} 只股票", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * 更新UI状态
     */
    private fun updateUIState(stocks: List<Stock>) {
        val count = stocks.size
        binding.tvSelectedCount.text = "已选择 $count 只股票"
        binding.btnStartAnalysis.isEnabled = count > 0 && 
            viewModel.analysisState.value !is AnalysisViewModel.AnalysisUiState.Analyzing
        
        if (count == 0) {
            binding.tvEmptySelection.visibility = View.VISIBLE
            binding.rvSelectedStocks.visibility = View.GONE
        } else {
            binding.tvEmptySelection.visibility = View.GONE
            binding.rvSelectedStocks.visibility = View.VISIBLE
        }
    }

    /**
     * 更新分析状态显示
     */
    private fun updateAnalysisState(state: AnalysisViewModel.AnalysisUiState) {
        when (state) {
            is AnalysisViewModel.AnalysisUiState.Idle -> {
                binding.tvAnalysisStatus.visibility = View.GONE
                binding.progressBar.visibility = View.GONE
            }
            is AnalysisViewModel.AnalysisUiState.Analyzing -> {
                binding.tvAnalysisStatus.visibility = View.VISIBLE
                binding.tvAnalysisStatus.text = "正在分析: ${state.currentStock} (${state.progress}/${state.total})"
                binding.progressBar.visibility = View.VISIBLE
            }
            is AnalysisViewModel.AnalysisUiState.Completed -> {
                binding.tvAnalysisStatus.visibility = View.VISIBLE
                binding.tvAnalysisStatus.text = "分析完成"
                binding.progressBar.visibility = View.GONE
            }
            is AnalysisViewModel.AnalysisUiState.Error -> {
                binding.tvAnalysisStatus.visibility = View.VISIBLE
                binding.tvAnalysisStatus.text = "分析失败: ${state.message}"
                binding.progressBar.visibility = View.GONE
            }
        }
    }

    /**
     * 显示股票选择对话框
     */
    private fun showStockSelectionDialog() {
        val stocks = viewModel.watchlist.value
        if (stocks.isEmpty()) {
            Toast.makeText(context, "自选列表为空，请先添加股票", Toast.LENGTH_SHORT).show()
            return
        }

        val stockNames = stocks.map { it.getDisplayName() }.toTypedArray()
        val selectedItems = BooleanArray(stocks.size) { index ->
            viewModel.selectedStocks.value.contains(stocks[index])
        }

        AlertDialog.Builder(context)
            .setTitle("选择股票")
            .setMultiChoiceItems(stockNames, selectedItems) { _, which, isChecked ->
                if (isChecked) {
                    viewModel.addSelectedStock(stocks[which])
                } else {
                    viewModel.removeSelectedStock(stocks[which])
                }
            }
            .setPositiveButton("确定", null)
            .setNegativeButton("取消", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

/**
 * 已选股票适配器
 */
class SelectedStockAdapter(
    private val onRemoveClick: (Stock) -> Unit
) : androidx.recyclerview.widget.ListAdapter<Stock, SelectedStockAdapter.ViewHolder>(
    androidx.recyclerview.widget.DiffUtil.ItemCallback<Stock>() {
        override fun areItemsTheSame(oldItem: Stock, newItem: Stock): Boolean {
            return oldItem.symbol == newItem.symbol
        }

        override fun areContentsTheSame(oldItem: Stock, newItem: Stock): Boolean {
            return oldItem == newItem
        }
    }
) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = com.example.stockanalysis.databinding.ItemSelectedStockBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(
        private val binding: com.example.stockanalysis.databinding.ItemSelectedStockBinding
    ) : androidx.recyclerview.widget.RecyclerView.ViewHolder(binding.root) {

        fun bind(stock: Stock) {
            binding.tvStockName.text = stock.name
            binding.tvStockSymbol.text = stock.symbol
            binding.btnRemove.setOnClickListener { onRemoveClick(stock) }
        }
    }
}
