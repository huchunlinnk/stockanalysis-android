package com.example.stockanalysis.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.stockanalysis.data.model.AnalysisResult
import com.example.stockanalysis.data.model.Decision
import com.example.stockanalysis.databinding.FragmentHistoryBinding
import com.example.stockanalysis.ui.viewmodel.HistoryViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * 历史Fragment
 * 显示分析历史，支持查看详情和删除记录
 */
@AndroidEntryPoint
class HistoryFragment : Fragment() {

    private var _binding: FragmentHistoryBinding? = null
    private val binding get() = _binding!!
    private val viewModel: HistoryViewModel by activityViewModels()

    private lateinit var historyAdapter: HistoryAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHistoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews()
        observeViewModel()
    }

    private fun initViews() {
        // 初始化RecyclerView
        historyAdapter = HistoryAdapter(
            onItemClick = { result ->
                (activity as? MainActivity)?.openAnalysisResult(result.id)
            },
            onDeleteClick = { result ->
                showDeleteConfirmDialog(result)
            }
        )

        binding.rvHistory.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = historyAdapter
        }

        // 清空历史按钮
        binding.btnClearHistory.setOnClickListener {
            showClearHistoryConfirmDialog()
        }

        // 刷新按钮
        binding.btnRefresh.setOnClickListener {
            viewModel.refreshHistory()
        }

        // 筛选按钮
        binding.chipGroupFilter.setOnCheckedStateChangeListener { _, checkedIds ->
            when {
                checkedIds.contains(R.id.chipAll) -> viewModel.setFilter(HistoryViewModel.FilterType.ALL)
                checkedIds.contains(R.id.chipBuy) -> viewModel.setFilter(HistoryViewModel.FilterType.BUY)
                checkedIds.contains(R.id.chipSell) -> viewModel.setFilter(HistoryViewModel.FilterType.SELL)
                checkedIds.contains(R.id.chipHold) -> viewModel.setFilter(HistoryViewModel.FilterType.HOLD)
            }
        }
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.filteredResults.collectLatest { results ->
                        historyAdapter.submitList(results)
                        binding.tvEmpty.visibility = 
                            if (results.isEmpty()) View.VISIBLE else View.GONE
                        binding.btnClearHistory.isEnabled = results.isNotEmpty()
                    }
                }

                launch {
                    viewModel.isLoading.collectLatest { isLoading ->
                        binding.swipeRefresh.isRefreshing = isLoading
                    }
                }

                launch {
                    viewModel.errorMessage.collectLatest { error ->
                        error?.let {
                            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
                        }
                    }
                }

                launch {
                    viewModel.statistics.collectLatest { stats ->
                        updateStatistics(stats)
                    }
                }
            }
        }

        // 下拉刷新
        binding.swipeRefresh.setOnRefreshListener {
            viewModel.refreshHistory()
        }
    }

    /**
     * 更新统计信息
     */
    private fun updateStatistics(stats: HistoryViewModel.HistoryStatistics) {
        binding.tvTotalCount.text = "总记录: ${stats.totalCount}"
        binding.tvBuyCount.text = "买入建议: ${stats.buyCount}"
        binding.tvSellCount.text = "卖出建议: ${stats.sellCount}"
        binding.tvHoldCount.text = "观望建议: ${stats.holdCount}"
        binding.tvAvgScore.text = "平均评分: ${String.format("%.1f", stats.averageScore)}"
    }

    /**
     * 显示删除确认对话框
     */
    private fun showDeleteConfirmDialog(result: AnalysisResult) {
        AlertDialog.Builder(context)
            .setTitle("删除记录")
            .setMessage("确定要删除这条分析记录吗？")
            .setPositiveButton("删除") { _, _ ->
                viewModel.deleteResult(result.id)
            }
            .setNegativeButton("取消", null)
            .show()
    }

    /**
     * 显示清空历史确认对话框
     */
    private fun showClearHistoryConfirmDialog() {
        AlertDialog.Builder(context)
            .setTitle("清空历史")
            .setMessage("确定要清空所有分析历史吗？此操作不可撤销。")
            .setPositiveButton("清空") { _, _ ->
                viewModel.clearHistory()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

/**
 * 历史记录适配器
 */
class HistoryAdapter(
    private val onItemClick: (AnalysisResult) -> Unit,
    private val onDeleteClick: (AnalysisResult) -> Unit
) : androidx.recyclerview.widget.ListAdapter<AnalysisResult, HistoryAdapter.ViewHolder>(
    androidx.recyclerview.widget.DiffUtil.ItemCallback<AnalysisResult>() {
        override fun areItemsTheSame(oldItem: AnalysisResult, newItem: AnalysisResult): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: AnalysisResult, newItem: AnalysisResult): Boolean {
            return oldItem == newItem
        }
    }
) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = com.example.stockanalysis.databinding.ItemHistoryBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(
        private val binding: com.example.stockanalysis.databinding.ItemHistoryBinding
    ) : androidx.recyclerview.widget.RecyclerView.ViewHolder(binding.root) {

        private val dateFormat = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())

        fun bind(result: AnalysisResult) {
            binding.tvStockName.text = result.stockName
            binding.tvStockSymbol.text = result.stockSymbol
            binding.tvAnalysisTime.text = dateFormat.format(result.analysisTime)
            binding.tvSummary.text = result.summary
            binding.tvScore.text = "${result.score}分"

            // 决策标签
            val decisionText = when (result.decision) {
                Decision.STRONG_BUY -> "强烈买入"
                Decision.BUY -> "买入"
                Decision.HOLD -> "观望"
                Decision.SELL -> "卖出"
                Decision.STRONG_SELL -> "强烈卖出"
            }
            binding.tvDecision.text = decisionText

            // 决策颜色
            val decisionColor = when (result.decision) {
                Decision.STRONG_BUY, Decision.BUY -> android.R.color.holo_red_dark
                Decision.SELL, Decision.STRONG_SELL -> android.R.color.holo_green_dark
                Decision.HOLD -> android.R.color.darker_gray
            }
            binding.tvDecision.setTextColor(binding.root.context.getColor(decisionColor))

            // 置信度
            binding.tvConfidence.text = when (result.confidence) {
                com.example.stockanalysis.data.model.ConfidenceLevel.HIGH -> "高置信度"
                com.example.stockanalysis.data.model.ConfidenceLevel.MEDIUM -> "中置信度"
                com.example.stockanalysis.data.model.ConfidenceLevel.LOW -> "低置信度"
            }

            binding.root.setOnClickListener { onItemClick(result) }
            binding.btnDelete.setOnClickListener { onDeleteClick(result) }
        }
    }
}
