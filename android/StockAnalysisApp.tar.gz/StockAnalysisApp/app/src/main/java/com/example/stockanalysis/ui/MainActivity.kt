package com.example.stockanalysis.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.stockanalysis.R
import com.example.stockanalysis.databinding.ActivityMainBinding
import com.example.stockanalysis.ui.viewmodel.MainViewModel
import dagger.hilt.android.AndroidEntryPoint

/**
 * 主Activity，包含底部导航栏
 * 切换首页、自选、分析、历史四个Fragment
 */
@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initViews()
        observeViewModel()
    }

    private fun initViews() {
        // 设置底部导航栏点击事件
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    switchFragment(HOME_FRAGMENT_TAG)
                    true
                }
                R.id.nav_watchlist -> {
                    switchFragment(WATCHLIST_FRAGMENT_TAG)
                    true
                }
                R.id.nav_analysis -> {
                    switchFragment(ANALYSIS_FRAGMENT_TAG)
                    true
                }
                R.id.nav_history -> {
                    switchFragment(HISTORY_FRAGMENT_TAG)
                    true
                }
                else -> false
            }
        }

        // 默认显示首页
        if (supportFragmentManager.findFragmentByTag(HOME_FRAGMENT_TAG) == null) {
            binding.bottomNavigation.selectedItemId = R.id.nav_home
        }
    }

    private fun observeViewModel() {
        viewModel.currentTab.observe(this) { tabIndex ->
            val itemId = when (tabIndex) {
                0 -> R.id.nav_home
                1 -> R.id.nav_watchlist
                2 -> R.id.nav_analysis
                3 -> R.id.nav_history
                else -> R.id.nav_home
            }
            if (binding.bottomNavigation.selectedItemId != itemId) {
                binding.bottomNavigation.selectedItemId = itemId
            }
        }
    }

    /**
     * 切换Fragment
     */
    private fun switchFragment(tag: String) {
        val fragmentManager = supportFragmentManager
        val transaction = fragmentManager.beginTransaction()

        // 隐藏所有Fragment
        fragmentManager.fragments.forEach { fragment ->
            if (fragment.isVisible) {
                transaction.hide(fragment)
            }
        }

        // 查找或创建目标Fragment
        var targetFragment = fragmentManager.findFragmentByTag(tag)
        if (targetFragment == null) {
            targetFragment = createFragment(tag)
            transaction.add(R.id.nav_host_fragment, targetFragment, tag)
        } else {
            transaction.show(targetFragment)
        }

        transaction.commit()

        // 更新ViewModel中的当前tab
        val tabIndex = when (tag) {
            HOME_FRAGMENT_TAG -> 0
            WATCHLIST_FRAGMENT_TAG -> 1
            ANALYSIS_FRAGMENT_TAG -> 2
            HISTORY_FRAGMENT_TAG -> 3
            else -> 0
        }
        viewModel.setCurrentTab(tabIndex)
    }

    /**
     * 根据tag创建对应的Fragment
     */
    private fun createFragment(tag: String): Fragment {
        return when (tag) {
            HOME_FRAGMENT_TAG -> HomeFragment()
            WATCHLIST_FRAGMENT_TAG -> WatchlistFragment()
            ANALYSIS_FRAGMENT_TAG -> AnalysisFragment()
            HISTORY_FRAGMENT_TAG -> HistoryFragment()
            else -> HomeFragment()
        }
    }

    /**
     * 打开股票详情页
     */
    fun openStockDetail(symbol: String, name: String) {
        val intent = Intent(this, StockDetailActivity::class.java).apply {
            putExtra(StockDetailActivity.EXTRA_SYMBOL, symbol)
            putExtra(StockDetailActivity.EXTRA_NAME, name)
        }
        startActivity(intent)
    }

    /**
     * 打开分析结果页
     */
    fun openAnalysisResult(analysisId: String) {
        val intent = Intent(this, AnalysisResultActivity::class.java).apply {
            putExtra(AnalysisResultActivity.EXTRA_ANALYSIS_ID, analysisId)
        }
        startActivity(intent)
    }

    /**
     * 打开设置页面
     */
    fun openSettings() {
        val intent = Intent(this, SettingsActivity::class.java)
        startActivity(intent)
    }

    companion object {
        private const val HOME_FRAGMENT_TAG = "home"
        private const val WATCHLIST_FRAGMENT_TAG = "watchlist"
        private const val ANALYSIS_FRAGMENT_TAG = "analysis"
        private const val HISTORY_FRAGMENT_TAG = "history"
    }
}
