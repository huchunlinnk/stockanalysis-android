package com.example.stockanalysis.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.stockanalysis.data.model.Stock
import com.example.stockanalysis.data.model.StockQuote
import com.example.stockanalysis.data.model.TechnicalIndicators
import com.example.stockanalysis.data.repository.AnalysisRepository
import com.example.stockanalysis.data.repository.StockRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * 股票详情ViewModel
 */
@HiltViewModel
class StockDetailViewModel @Inject constructor(
    private val stockRepository: StockRepository,
    private val analysisRepository: AnalysisRepository
) : ViewModel() {

    private val _stockQuote = MutableStateFlow<StockQuote?>(null)
    val stockQuote: StateFlow<StockQuote?> = _stockQuote

    private val _technicalIndicators = MutableStateFlow<TechnicalIndicators?>(null)
    val technicalIndicators: StateFlow<TechnicalIndicators?> = _technicalIndicators

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage

    private val _analysisEvent = MutableSharedFlow<AnalysisEvent>()
    val analysisEvent: SharedFlow<AnalysisEvent> = _analysisEvent

    private var currentSymbol: String = ""
    private var currentName: String = ""

    /**
     * 加载股票详情
     */
    fun loadStockDetail(symbol: String, name: String) {
        currentSymbol = symbol
        currentName = name
        refreshData()
    }

    /**
     * 刷新数据
     */
    fun refreshData() {
        if (currentSymbol.isEmpty()) return
        
        viewModelScope.launch {
            _isLoading.value = true
            
            // 加载行情
            val quoteResult = stockRepository.getQuote(currentSymbol)
            quoteResult.onSuccess { quote ->
                _stockQuote.value = quote
            }.onFailure { error ->
                _errorMessage.value = "获取行情失败: ${error.message}"
            }

            // 加载技术指标
            val techResult = stockRepository.getTechnicalIndicators(currentSymbol)
            techResult.onSuccess { indicators ->
                _technicalIndicators.value = indicators
            }

            _isLoading.value = false
        }
    }

    /**
     * 开始分析
     */
    fun startAnalysis() {
        if (currentSymbol.isEmpty() || currentName.isEmpty()) return
        
        viewModelScope.launch {
            _isLoading.value = true
            analysisRepository.analyzeStock(currentSymbol, currentName).collect { state ->
                when (state) {
                    is com.example.stockanalysis.data.repository.AnalysisState.Success -> {
                        _isLoading.value = false
                        _analysisEvent.emit(AnalysisEvent.NavigateToResult(state.result.id))
                    }
                    is com.example.stockanalysis.data.repository.AnalysisState.Error -> {
                        _isLoading.value = false
                        _errorMessage.value = state.message
                    }
                    else -> {}
                }
            }
        }
    }

    /**
     * 添加到自选
     */
    fun addToWatchlist() {
        if (currentSymbol.isEmpty() || currentName.isEmpty()) return
        
        viewModelScope.launch {
            val stock = Stock(
                symbol = currentSymbol,
                name = currentName,
                market = com.example.stockanalysis.data.model.MarketType.A_SHARE
            )
            val result = stockRepository.addStock(stock)
            result.onSuccess {
                _errorMessage.value = "已添加到自选"
            }.onFailure { error ->
                _errorMessage.value = "添加失败: ${error.message}"
            }
        }
    }

    sealed class AnalysisEvent {
        data class NavigateToResult(val analysisId: String) : AnalysisEvent()
    }
}
