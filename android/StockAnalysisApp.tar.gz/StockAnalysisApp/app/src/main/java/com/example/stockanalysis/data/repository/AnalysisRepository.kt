package com.example.stockanalysis.data.repository

import androidx.lifecycle.LiveData
import com.example.stockanalysis.data.api.LLMApiService
import com.example.stockanalysis.data.api.Message
import com.example.stockanalysis.data.api.ChatCompletionRequest
import com.example.stockanalysis.data.local.AnalysisResultDao
import com.example.stockanalysis.data.model.*
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 分析仓库接口
 */
interface AnalysisRepository {
    fun getAllResults(): LiveData<List<AnalysisResult>>
    suspend fun getResultsBySymbol(symbol: String): List<AnalysisResult>
    suspend fun getLatestResultBySymbol(symbol: String): AnalysisResult?
    suspend fun getResultById(id: String): AnalysisResult?
    suspend fun analyzeStock(symbol: String, stockName: String): Flow<AnalysisState>
    suspend fun analyzeStocks(stocks: List<Stock>): Flow<BatchAnalysisState>
    suspend fun deleteResult(id: String)
    suspend fun clearHistory()
}

/**
 * 分析状态
 */
sealed class AnalysisState {
    object Loading : AnalysisState()
    data class Progress(val message: String) : AnalysisState()
    data class Success(val result: AnalysisResult) : AnalysisState()
    data class Error(val message: String) : AnalysisState()
}

/**
 * 批量分析状态
 */
sealed class BatchAnalysisState {
    object Loading : BatchAnalysisState()
    data class Progress(
        val current: Int,
        val total: Int,
        val currentStock: String,
        val results: List<AnalysisResult>
    ) : BatchAnalysisState()
    data class Success(val results: List<AnalysisResult>) : BatchAnalysisState()
    data class Error(val message: String) : BatchAnalysisState()
}

/**
 * 分析仓库实现
 */
@Singleton
class AnalysisRepositoryImpl @Inject constructor(
    private val analysisResultDao: AnalysisResultDao,
    private val llmApiService: LLMApiService,
    private val stockRepository: StockRepository
) : AnalysisRepository {

    private val gson = Gson()

    override fun getAllResults(): LiveData<List<AnalysisResult>> {
        return analysisResultDao.getAllResults()
    }

    override suspend fun getResultsBySymbol(symbol: String): List<AnalysisResult> {
        return analysisResultDao.getResultsBySymbol(symbol).value ?: emptyList()
    }

    override suspend fun getLatestResultBySymbol(symbol: String): AnalysisResult? {
        return analysisResultDao.getLatestResultBySymbol(symbol)
    }

    override suspend fun getResultById(id: String): AnalysisResult? {
        return analysisResultDao.getResultById(id)
    }

    override suspend fun analyzeStock(symbol: String, stockName: String): Flow<AnalysisState> = flow {
        emit(AnalysisState.Loading)
        emit(AnalysisState.Progress("正在获取股票数据..."))
        
        try {
            // 获取股票数据
            val quoteResult = stockRepository.getQuote(symbol)
            if (quoteResult.isFailure) {
                emit(AnalysisState.Error("获取股票数据失败"))
                return@flow
            }
            
            val quote = quoteResult.getOrNull()
            
            emit(AnalysisState.Progress("正在进行AI分析..."))
            
            // 构建分析提示词
            val prompt = buildAnalysisPrompt(symbol, stockName, quote)
            
            // 调用 LLM API
            val request = ChatCompletionRequest(
                model = "gpt-3.5-turbo",
                messages = listOf(
                    Message("system", SYSTEM_PROMPT),
                    Message("user", prompt)
                ),
                temperature = 0.7,
                maxTokens = 2000
            )
            
            val response = llmApiService.chatCompletion(request)
            
            if (response.isSuccessful) {
                val completionResponse = response.body()
                val content = completionResponse?.choices?.firstOrNull()?.message?.content
                
                if (content != null) {
                    // 解析 AI 响应
                    val result = parseAnalysisResponse(symbol, stockName, content)
                    
                    // 保存到数据库
                    analysisResultDao.insertResult(result)
                    
                    emit(AnalysisState.Success(result))
                } else {
                    emit(AnalysisState.Error("AI 响应为空"))
                }
            } else {
                emit(AnalysisState.Error("AI 分析失败: ${response.code()}"))
            }
            
        } catch (e: Exception) {
            emit(AnalysisState.Error("分析失败: ${e.message}"))
        }
    }.flowOn(Dispatchers.IO)

    override suspend fun analyzeStocks(stocks: List<Stock>): Flow<BatchAnalysisState> = flow {
        emit(BatchAnalysisState.Loading)
        
        val results = mutableListOf<AnalysisResult>()
        
        stocks.forEachIndexed { index, stock ->
            emit(BatchAnalysisState.Progress(
                current = index + 1,
                total = stocks.size,
                currentStock = stock.name,
                results = results.toList()
            ))
            
            try {
                // 顺序执行分析
                val quoteResult = stockRepository.getQuote(stock.symbol)
                val quote = quoteResult.getOrNull()
                
                val prompt = buildAnalysisPrompt(stock.symbol, stock.name, quote)
                
                val request = ChatCompletionRequest(
                    model = "gpt-3.5-turbo",
                    messages = listOf(
                        Message("system", SYSTEM_PROMPT),
                        Message("user", prompt)
                    ),
                    temperature = 0.7,
                    maxTokens = 2000
                )
                
                val response = llmApiService.chatCompletion(request)
                
                if (response.isSuccessful) {
                    val content = response.body()?.choices?.firstOrNull()?.message?.content
                    if (content != null) {
                        val result = parseAnalysisResponse(stock.symbol, stock.name, content)
                        analysisResultDao.insertResult(result)
                        results.add(result)
                    }
                }
            } catch (e: Exception) {
                // 继续分析下一只
            }
        }
        
        emit(BatchAnalysisState.Success(results))
    }.flowOn(Dispatchers.IO)

    override suspend fun deleteResult(id: String) {
        analysisResultDao.deleteResultById(id)
    }

    override suspend fun clearHistory() {
        analysisResultDao.deleteAllResults()
    }

    /**
     * 构建分析提示词
     */
    private fun buildAnalysisPrompt(symbol: String, name: String, quote: StockQuote?): String {
        val priceInfo = quote?.let {
            """
            当前价格: ${it.currentPrice}
            涨跌幅: ${it.changePercent}%
            开盘价: ${it.openPrice}
            最高价: ${it.highPrice}
            最低价: ${it.lowPrice}
            成交量: ${it.volume}
            """
        } ?: "暂无实时数据"
        
        return """
        请分析以下股票：
        
        股票代码: $symbol
        股票名称: $name
        
        行情数据:
        $priceInfo
        
        请提供以下分析内容：
        1. 一句话核心结论
        2. 决策建议（买入/观望/卖出）
        3. 综合评分（0-100）
        4. 技术面分析
        5. 风险评估
        6. 操作建议（买入价、止损价、目标价）
        
        请以JSON格式返回。
        """
    }

    /**
     * 解析 AI 响应
     */
    private fun parseAnalysisResponse(symbol: String, name: String, content: String): AnalysisResult {
        // 这里简化处理，实际需要解析 JSON
        return AnalysisResult(
            id = UUID.randomUUID().toString(),
            stockSymbol = symbol,
            stockName = name,
            decision = Decision.HOLD,
            score = 50,
            confidence = ConfidenceLevel.MEDIUM,
            summary = "AI分析完成",
            reasoning = content,
            technicalAnalysis = null,
            fundamentalAnalysis = null,
            sentimentAnalysis = null,
            riskAssessment = null,
            actionPlan = null,
            rawResponse = content
        )
    }

    companion object {
        private const val SYSTEM_PROMPT = """
        你是一位专业的股票分析师，擅长技术分析和基本面分析。
        请基于提供的数据给出客观、专业的分析意见。
        注意：分析仅供参考，不构成投资建议。
        """
    }
}
