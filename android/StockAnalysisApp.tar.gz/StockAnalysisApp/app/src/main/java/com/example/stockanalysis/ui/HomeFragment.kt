package com.example.stockanalysis.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.stockanalysis.data.model.MarketIndex
import com.example.stockanalysis.data.model.MarketOverview
import com.example.stockanalysis.databinding.FragmentHomeBinding
import com.example.stockanalysis.ui.viewmodel.HomeViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * 首页Fragment
 * 包含搜索框、市场状态、快捷操作按钮
 */
@AndroidEntryPoint
class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: HomeViewModel by activityViewModels()

    private lateinit var indexAdapter: MarketIndexAdapter
    private lateinit var searchResultAdapter: SearchResultAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews()
        observeViewModel()
        viewModel.loadMarketOverview()
    }

    private fun initViews() {
        // 初始化市场指数RecyclerView
        indexAdapter = MarketIndexAdapter { index ->
            // 点击指数，可以跳转到指数详情
            Toast.makeText(context, "点击了: ${index.name}", Toast.LENGTH_SHORT).show()
        }
        binding.rvIndices.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = indexAdapter
        }

        // 初始化搜索结果RecyclerView
        searchResultAdapter = SearchResultAdapter { stock ->
            // 点击搜索结果，跳转到股票详情
            (activity as? MainActivity)?.openStockDetail(stock.symbol, stock.name)
            binding.etSearch.text?.clear()
            binding.rvSearchResults.visibility = View.GONE
        }
        binding.rvSearchResults.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = searchResultAdapter
        }

        // 搜索框监听
        binding.etSearch.doAfterTextChanged { text ->
            val query = text?.toString()?.trim() ?: ""
            if (query.length >= 2) {
                viewModel.searchStocks(query)
                binding.rvSearchResults.visibility = View.VISIBLE
            } else {
                binding.rvSearchResults.visibility = View.GONE
            }
        }

        // 快捷操作按钮
        binding.btnQuickAnalysis.setOnClickListener {
            (activity as? MainActivity)?.let { mainActivity ->
                mainActivity.findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(
                    R.id.bottom_navigation
                )?.selectedItemId = R.id.nav_analysis
            }
        }

        binding.btnWatchlist.setOnClickListener {
            (activity as? MainActivity)?.let { mainActivity ->
                mainActivity.findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(
                    R.id.bottom_navigation
                )?.selectedItemId = R.id.nav_watchlist
            }
        }

        binding.btnHistory.setOnClickListener {
            (activity as? MainActivity)?.let { mainActivity ->
                mainActivity.findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(
                    R.id.bottom_navigation
                )?.selectedItemId = R.id.nav_history
            }
        }

        // 设置按钮
        binding.btnSettings.setOnClickListener {
            (activity as? MainActivity)?.openSettings()
        }

        // 刷新按钮
        binding.btnRefresh.setOnClickListener {
            viewModel.loadMarketOverview()
        }
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.marketOverview.collectLatest { overview ->
                        overview?.let { updateMarketOverview(it) }
                    }
                }

                launch {
                    viewModel.isLoading.collectLatest { isLoading ->
                        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
                    }
                }

                launch {
                    viewModel.errorMessage.collectLatest { error ->
                        error?.let {
                            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
                        }
                    }
                }

                launch {
                    viewModel.searchResults.collectLatest { results ->
                        searchResultAdapter.submitList(results)
                    }
                }
            }
        }
    }

    /**
     * 更新市场概览数据
     */
    private fun updateMarketOverview(overview: MarketOverview) {
        // 更新市场指数
        indexAdapter.submitList(overview.indices)

        // 更新市场统计
        val stats = overview.stats
        binding.tvRisingCount.text = stats.risingCount.toString()
        binding.tvFallingCount.text = stats.fallingCount.toString()
        binding.tvFlatCount.text = stats.flatCount.toString()

        // 更新涨跌停家数
        binding.tvLimitUpCount.text = "涨停: ${stats.limitUpCount}"
        binding.tvLimitDownCount.text = "跌停: ${stats.limitDownCount}"

        // 更新时间
        binding.tvUpdateTime.text = "更新时间: ${formatTime(overview.updateTime)}"
    }

    private fun formatTime(date: java.util.Date): String {
        val sdf = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
        return sdf.format(date)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

/**
 * 市场指数适配器（简单实现，实际应放在单独文件中）
 */
class MarketIndexAdapter(
    private val onItemClick: (MarketIndex) -> Unit
) : androidx.recyclerview.widget.ListAdapter<MarketIndex, MarketIndexAdapter.ViewHolder>(
    androidx.recyclerview.widget.DiffUtil.ItemCallback<MarketIndex>() {
        override fun areItemsTheSame(oldItem: MarketIndex, newItem: MarketIndex): Boolean {
            return oldItem.symbol == newItem.symbol
        }

        override fun areContentsTheSame(oldItem: MarketIndex, newItem: MarketIndex): Boolean {
            return oldItem == newItem
        }
    }
) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = com.example.stockanalysis.databinding.ItemMarketIndexBinding.inflate(
            android.view.LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(
        private val binding: com.example.stockanalysis.databinding.ItemMarketIndexBinding
    ) : androidx.recyclerview.widget.RecyclerView.ViewHolder(binding.root) {

        fun bind(index: MarketIndex) {
            binding.tvIndexName.text = index.name
            binding.tvIndexValue.text = String.format("%.2f", index.currentValue)
            binding.tvIndexChange.text = "${if (index.change >= 0) "+" else ""}${String.format("%.2f", index.changePercent)}%"
            
            val colorRes = when {
                index.change > 0 -> android.R.color.holo_red_dark
                index.change < 0 -> android.R.color.holo_green_dark
                else -> android.R.color.darker_gray
            }
            binding.tvIndexChange.setTextColor(binding.root.context.getColor(colorRes))

            binding.root.setOnClickListener { onItemClick(index) }
        }
    }
}

/**
 * 搜索结果适配器（简单实现，实际应放在单独文件中）
 */
class SearchResultAdapter(
    private val onItemClick: (com.example.stockanalysis.data.model.Stock) -> Unit
) : androidx.recyclerview.widget.ListAdapter<com.example.stockanalysis.data.model.Stock, SearchResultAdapter.ViewHolder>(
    androidx.recyclerview.widget.DiffUtil.ItemCallback<com.example.stockanalysis.data.model.Stock>() {
        override fun areItemsTheSame(oldItem: com.example.stockanalysis.data.model.Stock, newItem: com.example.stockanalysis.data.model.Stock): Boolean {
            return oldItem.symbol == newItem.symbol
        }

        override fun areContentsTheSame(oldItem: com.example.stockanalysis.data.model.Stock, newItem: com.example.stockanalysis.data.model.Stock): Boolean {
            return oldItem == newItem
        }
    }
) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = com.example.stockanalysis.databinding.ItemSearchResultBinding.inflate(
            android.view.LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(
        private val binding: com.example.stockanalysis.databinding.ItemSearchResultBinding
    ) : androidx.recyclerview.widget.RecyclerView.ViewHolder(binding.root) {

        fun bind(stock: com.example.stockanalysis.data.model.Stock) {
            binding.tvStockName.text = stock.name
            binding.tvStockSymbol.text = stock.symbol
            binding.tvStockMarket.text = stock.market.name
            binding.root.setOnClickListener { onItemClick(stock) }
        }
    }
}
