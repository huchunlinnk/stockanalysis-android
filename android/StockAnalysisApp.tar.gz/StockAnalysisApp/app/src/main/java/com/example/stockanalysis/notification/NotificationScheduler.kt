package com.example.stockanalysis.notification

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.util.Log
import androidx.work.WorkManager
import com.example.stockanalysis.data.local.PreferencesManager
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 通知调度器
 * 负责设置和管理所有通知相关的定时任务
 * 兼容 Android 12+ 的精确闹钟权限
 */
@Singleton
class NotificationScheduler @Inject constructor(
    @ApplicationContext private val context: Context,
    private val preferencesManager: PreferencesManager
) {

    companion object {
        private const val TAG = "NotificationScheduler"
        
        // Alarm action
        const val ACTION_DAILY_REMINDER = "com.example.stockanalysis.DAILY_REMINDER"
        const val ACTION_MARKET_OPEN = "com.example.stockanalysis.MARKET_OPEN"
        const val ACTION_MARKET_CLOSE = "com.example.stockanalysis.MARKET_CLOSE"
        
        // Request codes
        private const val REQUEST_CODE_DAILY_REMINDER = 1001
        private const val REQUEST_CODE_MARKET_OPEN = 1002
        private const val REQUEST_CODE_MARKET_CLOSE = 1003
        
        // Market hours (China A-share)
        private const val MARKET_OPEN_HOUR = 9
        private const val MARKET_OPEN_MINUTE = 30
        private const val MARKET_CLOSE_HOUR = 15
        private const val MARKET_CLOSE_MINUTE = 0
    }

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    /**
     * 重新设置所有任务（用于开机后或应用更新后）
     */
    fun rescheduleAllTasks() {
        Log.d(TAG, "Rescheduling all tasks")
        
        if (preferencesManager.isDailyReminderEnabled()) {
            scheduleDailyReminder(
                hour = preferencesManager.getDailyReminderHour(),
                minute = preferencesManager.getDailyReminderMinute()
            )
        }
        
        if (preferencesManager.isMarketHoursNotificationEnabled()) {
            scheduleMarketHoursNotifications()
        }

        // 重新设置 WorkManager 任务
        AnalysisWorker.scheduleDailyAnalysis(context)
    }

    /**
     * 设置每日提醒
     */
    fun scheduleDailyReminder(hour: Int = 9, minute: Int = 0) {
        Log.d(TAG, "Scheduling daily reminder at $hour:$minute")
        
        val intent = Intent(context, NotificationBroadcastReceiver::class.java).apply {
            action = ACTION_DAILY_REMINDER
        }
        
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE_DAILY_REMINDER,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val triggerTime = calculateNextTriggerTime(hour, minute)
        
        scheduleAlarm(triggerTime, pendingIntent)
        
        // 保存设置
        preferencesManager.setDailyReminderTime(hour, minute)
        preferencesManager.setDailyReminderEnabled(true)
    }

    /**
     * 取消每日提醒
     */
    fun cancelDailyReminder() {
        Log.d(TAG, "Cancelling daily reminder")
        
        val intent = Intent(context, NotificationBroadcastReceiver::class.java).apply {
            action = ACTION_DAILY_REMINDER
        }
        
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE_DAILY_REMINDER,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        alarmManager.cancel(pendingIntent)
        pendingIntent.cancel()
        
        preferencesManager.setDailyReminderEnabled(false)
    }

    /**
     * 设置交易时间通知（开盘和收盘提醒）
     */
    fun scheduleMarketHoursNotifications() {
        Log.d(TAG, "Scheduling market hours notifications")
        
        // 开盘提醒
        val openIntent = Intent(context, NotificationBroadcastReceiver::class.java).apply {
            action = ACTION_MARKET_OPEN
        }
        
        val openPendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE_MARKET_OPEN,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openTime = calculateNextTriggerTime(MARKET_OPEN_HOUR, MARKET_OPEN_MINUTE)
        scheduleAlarm(openTime, openPendingIntent)

        // 收盘提醒
        val closeIntent = Intent(context, NotificationBroadcastReceiver::class.java).apply {
            action = ACTION_MARKET_CLOSE
        }
        
        val closePendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE_MARKET_CLOSE,
            closeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val closeTime = calculateNextTriggerTime(MARKET_CLOSE_HOUR, MARKET_CLOSE_MINUTE)
        scheduleAlarm(closeTime, closePendingIntent)

        preferencesManager.setMarketHoursNotificationEnabled(true)
    }

    /**
     * 取消交易时间通知
     */
    fun cancelMarketHoursNotifications() {
        Log.d(TAG, "Cancelling market hours notifications")
        
        // 取消开盘提醒
        val openIntent = Intent(context, NotificationBroadcastReceiver::class.java).apply {
            action = ACTION_MARKET_OPEN
        }
        val openPendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE_MARKET_OPEN,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(openPendingIntent)
        openPendingIntent.cancel()

        // 取消收盘提醒
        val closeIntent = Intent(context, NotificationBroadcastReceiver::class.java).apply {
            action = ACTION_MARKET_CLOSE
        }
        val closePendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE_MARKET_CLOSE,
            closeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(closePendingIntent)
        closePendingIntent.cancel()

        preferencesManager.setMarketHoursNotificationEnabled(false)
    }

    /**
     * 设置自定义股票提醒
     */
    fun scheduleStockAlert(
        stockSymbol: String,
        targetPrice: Double,
        isAboveTarget: Boolean
    ) {
        Log.d(TAG, "Scheduling price alert for $stockSymbol at $targetPrice")
        
        // 创建定期分析任务来检查价格
        AnalysisWorker.scheduleCustomAnalysis(
            context = context,
            stockSymbol = stockSymbol,
            stockName = stockSymbol, // 可以从数据库获取真实名称
            intervalHours = 1 // 每小时检查一次
        )
        
        // 保存提醒设置
        preferencesManager.saveStockAlert(stockSymbol, targetPrice, isAboveTarget)
    }

    /**
     * 取消股票提醒
     */
    fun cancelStockAlert(stockSymbol: String) {
        Log.d(TAG, "Cancelling price alert for $stockSymbol")
        
        AnalysisWorker.cancelAnalysisForStock(context, stockSymbol)
        preferencesManager.removeStockAlert(stockSymbol)
    }

    /**
     * 取消所有通知和任务
     */
    fun cancelAll() {
        Log.d(TAG, "Cancelling all notifications and tasks")
        
        cancelDailyReminder()
        cancelMarketHoursNotifications()
        
        // 取消所有 WorkManager 任务
        WorkManager.getInstance(context).cancelAllWork()
        
        // 清除所有提醒设置
        preferencesManager.clearAllAlerts()
    }

    /**
     * 检查是否可以设置精确闹钟（Android 12+）
     */
    fun canScheduleExactAlarms(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }
    }

    /**
     * 请求精确闹钟权限（跳转到系统设置）
     */
    fun requestExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                data = android.net.Uri.parse("package:${context.packageName}")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        }
    }

    /**
     * 调度闹钟（根据系统版本选择合适的 API）
     */
    private fun scheduleAlarm(triggerTime: Long, pendingIntent: PendingIntent) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !canScheduleExactAlarms()) {
                // Android 12+ 没有精确闹钟权限，使用非精确闹钟
                Log.w(TAG, "Cannot schedule exact alarms, using inexact alarm")
                alarmManager.setInexactRepeating(
                    AlarmManager.RTC_WAKEUP,
                    triggerTime,
                    AlarmManager.INTERVAL_DAY,
                    pendingIntent
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                // Android 6+ 使用精确闹钟
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerTime,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    triggerTime,
                    pendingIntent
                )
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException when scheduling alarm", e)
            // 降级为非精确闹钟
            alarmManager.setInexactRepeating(
                AlarmManager.RTC_WAKEUP,
                triggerTime,
                AlarmManager.INTERVAL_DAY,
                pendingIntent
            )
        }
    }

    /**
     * 计算下一次触发时间
     */
    private fun calculateNextTriggerTime(hour: Int, minute: Int): Long {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        // 如果今天的时间已过，设置为明天
        if (calendar.timeInMillis <= System.currentTimeMillis()) {
            calendar.add(Calendar.DAY_OF_YEAR, 1)
        }

        return calendar.timeInMillis
    }
}
