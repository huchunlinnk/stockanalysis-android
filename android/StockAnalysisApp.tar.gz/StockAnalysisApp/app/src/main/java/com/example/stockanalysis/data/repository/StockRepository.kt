package com.example.stockanalysis.data.repository

import androidx.lifecycle.LiveData
import com.example.stockanalysis.data.api.StockApiService
import com.example.stockanalysis.data.local.StockDao
import com.example.stockanalysis.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 股票数据仓库接口
 */
interface StockRepository {
    fun getAllStocks(): LiveData<List<Stock>>
    suspend fun getAllStocksSync(): List<Stock>
    suspend fun getStockBySymbol(symbol: String): Stock?
    suspend fun addStock(stock: Stock): Result<Unit>
    suspend fun removeStock(symbol: String): Result<Unit>
    suspend fun updateStock(stock: Stock)
    suspend fun isStockExists(symbol: String): Boolean
    fun searchStocks(query: String): Flow<List<Stock>>
    
    // 行情数据
    suspend fun getQuote(symbol: String): Result<StockQuote>
    suspend fun getQuotes(symbols: List<String>): Result<List<StockQuote>>
    suspend fun getTechnicalIndicators(symbol: String): Result<TechnicalIndicators>
}

/**
 * 股票数据仓库实现
 */
@Singleton
class StockRepositoryImpl @Inject constructor(
    private val stockDao: StockDao,
    private val stockApiService: StockApiService
) : StockRepository {

    override fun getAllStocks(): LiveData<List<Stock>> {
        return stockDao.getAllStocks()
    }

    override suspend fun getAllStocksSync(): List<Stock> {
        return stockDao.getAllStocksSync()
    }

    override suspend fun getStockBySymbol(symbol: String): Stock? {
        return stockDao.getStockBySymbol(symbol)
    }

    override suspend fun addStock(stock: Stock): Result<Unit> {
        return try {
            stockDao.insertStock(stock)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun removeStock(symbol: String): Result<Unit> {
        return try {
            stockDao.deleteStockBySymbol(symbol)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun updateStock(stock: Stock) {
        stockDao.updateStock(stock)
    }

    override suspend fun isStockExists(symbol: String): Boolean {
        return stockDao.isStockExists(symbol)
    }

    override fun searchStocks(query: String): Flow<List<Stock>> = flow {
        // 本地搜索
        val localResults = stockDao.searchStocks(query)
        emit(localResults)
        
        // 远程搜索（如果需要）
        try {
            val response = stockApiService.searchStocks(query)
            if (response.isSuccessful) {
                response.body()?.let { emit(it) }
            }
        } catch (e: Exception) {
            // 网络请求失败，使用本地数据
        }
    }.flowOn(Dispatchers.IO)

    override suspend fun getQuote(symbol: String): Result<StockQuote> {
        return withContext(Dispatchers.IO) {
            try {
                val response = stockApiService.getQuote(symbol)
                if (response.isSuccessful) {
                    response.body()?.let {
                        Result.success(it)
                    } ?: Result.failure(IOException("Empty response"))
                } else {
                    Result.failure(IOException("API error: ${response.code()}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    override suspend fun getQuotes(symbols: List<String>): Result<List<StockQuote>> {
        return withContext(Dispatchers.IO) {
            try {
                val response = stockApiService.getQuotes(symbols.joinToString(","))
                if (response.isSuccessful) {
                    response.body()?.let {
                        Result.success(it)
                    } ?: Result.success(emptyList())
                } else {
                    Result.failure(IOException("API error: ${response.code()}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    override suspend fun getTechnicalIndicators(symbol: String): Result<TechnicalIndicators> {
        return withContext(Dispatchers.IO) {
            try {
                val response = stockApiService.getTechnicalIndicators(symbol)
                if (response.isSuccessful) {
                    response.body()?.let {
                        Result.success(it)
                    } ?: Result.failure(IOException("Empty response"))
                } else {
                    Result.failure(IOException("API error: ${response.code()}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }
}
