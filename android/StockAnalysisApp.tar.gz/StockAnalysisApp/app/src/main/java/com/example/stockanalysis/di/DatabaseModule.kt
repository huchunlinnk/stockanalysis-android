package com.example.stockanalysis.di

import android.content.Context
import com.example.stockanalysis.data.local.AnalysisResultDao
import com.example.stockanalysis.data.local.StockDao
import com.example.stockanalysis.data.local.StockDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * 数据库模块
 */
@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): StockDatabase {
        return StockDatabase.getDatabase(context)
    }

    @Provides
    fun provideStockDao(database: StockDatabase): StockDao {
        return database.stockDao()
    }

    @Provides
    fun provideAnalysisResultDao(database: StockDatabase): AnalysisResultDao {
        return database.analysisResultDao()
    }
}
