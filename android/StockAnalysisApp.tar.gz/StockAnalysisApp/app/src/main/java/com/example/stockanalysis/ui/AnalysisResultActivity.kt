package com.example.stockanalysis.ui

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.stockanalysis.R
import com.example.stockanalysis.data.model.*
import com.example.stockanalysis.databinding.ActivityAnalysisResultBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * 分析结果页面
 * 显示AI分析结果详情
 */
@AndroidEntryPoint
class AnalysisResultActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAnalysisResultBinding
    private val viewModel: AnalysisResultViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAnalysisResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val analysisId = intent.getStringExtra(EXTRA_ANALYSIS_ID) ?: ""
        val symbol = intent.getStringExtra(EXTRA_SYMBOL) ?: ""
        val name = intent.getStringExtra(EXTRA_NAME) ?: ""

        if (analysisId.isEmpty() && symbol.isEmpty()) {
            Toast.makeText(this, "参数无效", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        initViews()
        observeViewModel()
        
        if (analysisId.isNotEmpty()) {
            viewModel.loadAnalysisResult(analysisId)
        } else {
            viewModel.startNewAnalysis(symbol, name)
        }
    }

    private fun initViews() {
        // 设置Toolbar
        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
        }

        // 初始化检查清单RecyclerView
        binding.rvChecklist.layoutManager = LinearLayoutManager(this)
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.analysisResult.collectLatest { result ->
                        result?.let { updateUI(it) }
                    }
                }

                launch {
                    viewModel.isLoading.collectLatest { isLoading ->
                        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
                        binding.contentScroll.visibility = if (isLoading) View.GONE else View.VISIBLE
                    }
                }

                launch {
                    viewModel.errorMessage.collectLatest { error ->
                        error?.let {
                            Toast.makeText(this@AnalysisResultActivity, it, Toast.LENGTH_SHORT).show()
                        }
                    }
                }

                launch {
                    viewModel.shareEvent.collectLatest { event ->
                        when (event) {
                            is AnalysisResultViewModel.ShareEvent.Success -> {
                                shareAnalysisResult(event.content)
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * 更新UI
     */
    private fun updateUI(result: AnalysisResult) {
        supportActionBar?.title = result.stockName
        supportActionBar?.subtitle = result.stockSymbol

        // 基本信息
        binding.tvStockName.text = result.stockName
        binding.tvStockSymbol.text = result.stockSymbol
        binding.tvAnalysisTime.text = formatTime(result.analysisTime)

        // 决策建议
        binding.tvDecision.text = getDecisionText(result.decision)
        val decisionColor = when (result.decision) {
            Decision.STRONG_BUY, Decision.BUY -> getColor(android.R.color.holo_red_dark)
            Decision.SELL, Decision.STRONG_SELL -> getColor(android.R.color.holo_green_dark)
            Decision.HOLD -> getColor(android.R.color.darker_gray)
        }
        binding.tvDecision.setTextColor(decisionColor)
        binding.cardDecision.setCardBackgroundColor(decisionColor)

        // 评分
        binding.tvScore.text = "${result.score}"
        binding.tvMaxScore.text = "/100"
        binding.progressScore.progress = result.score
        
        // 置信度
        binding.tvConfidence.text = when (result.confidence) {
            ConfidenceLevel.HIGH -> "高置信度"
            ConfidenceLevel.MEDIUM -> "中置信度"
            ConfidenceLevel.LOW -> "低置信度"
        }

        // 核心结论
        binding.tvSummary.text = result.summary

        // 推理过程
        binding.tvReasoning.text = result.reasoning

        // 技术分析
        result.technicalAnalysis?.let { technical ->
            binding.tvTechnicalTrend.text = technical.trend
            binding.tvTechnicalMa.text = technical.maAlignment
            binding.tvTechnicalVolume.text = technical.volumeAnalysis
            binding.tvTechnicalScore.text = "${technical.technicalScore}分"
            binding.layoutTechnical.visibility = View.VISIBLE
        } ?: run {
            binding.layoutTechnical.visibility = View.GONE
        }

        // 基本面分析
        result.fundamentalAnalysis?.let { fundamental ->
            binding.tvFundamentalValuation.text = fundamental.valuation
            binding.tvFundamentalGrowth.text = fundamental.growth
            binding.tvFundamentalProfitability.text = fundamental.profitability
            binding.tvFundamentalScore.text = "${fundamental.fundamentalScore}分"
            binding.layoutFundamental.visibility = View.VISIBLE
        } ?: run {
            binding.layoutFundamental.visibility = View.GONE
        }

        // 风险评估
        result.riskAssessment?.let { risk ->
            binding.tvRiskLevel.text = getRiskLevelText(risk.riskLevel)
            binding.tvRiskVolatility.text = risk.volatility
            binding.tvRiskLiquidity.text = risk.liquidityRisk
            binding.tvRiskMarket.text = risk.marketRisk
            binding.layoutRisk.visibility = View.VISIBLE
        } ?: run {
            binding.layoutRisk.visibility = View.GONE
        }

        // 行动计划
        result.actionPlan?.let { action ->
            binding.tvEntryPrice.text = action.entryPrice?.let { String.format("%.2f", it) } ?: "--"
            binding.tvStopLoss.text = action.stopLossPrice?.let { String.format("%.2f", it) } ?: "--"
            binding.tvTargetPrice.text = action.targetPrice?.let { String.format("%.2f", it) } ?: "--"
            binding.tvPositionSize.text = action.positionSize ?: "--"
            binding.tvTimeHorizon.text = action.timeHorizon ?: "--"
            binding.layoutAction.visibility = View.VISIBLE

            // 检查清单
            if (action.checkList.isNotEmpty()) {
                binding.rvChecklist.adapter = ChecklistAdapter(action.checkList)
                binding.tvChecklistTitle.visibility = View.VISIBLE
                binding.rvChecklist.visibility = View.VISIBLE
            } else {
                binding.tvChecklistTitle.visibility = View.GONE
                binding.rvChecklist.visibility = View.GONE
            }
        } ?: run {
            binding.layoutAction.visibility = View.GONE
            binding.tvChecklistTitle.visibility = View.GONE
            binding.rvChecklist.visibility = View.GONE
        }
    }

    private fun getDecisionText(decision: Decision): String {
        return when (decision) {
            Decision.STRONG_BUY -> "强烈买入"
            Decision.BUY -> "买入"
            Decision.HOLD -> "观望"
            Decision.SELL -> "卖出"
            Decision.STRONG_SELL -> "强烈卖出"
        }
    }

    private fun getRiskLevelText(level: RiskLevel): String {
        return when (level) {
            RiskLevel.LOW -> "低风险"
            RiskLevel.MEDIUM -> "中风险"
            RiskLevel.HIGH -> "高风险"
        }
    }

    private fun formatTime(date: java.util.Date): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        return "分析时间: ${sdf.format(date)}"
    }

    private fun shareAnalysisResult(content: String) {
        val shareIntent = android.content.Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "股票分析结果")
            putExtra(Intent.EXTRA_TEXT, content)
        }
        startActivity(Intent.createChooser(shareIntent, "分享分析结果"))
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_analysis_result, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            R.id.action_share -> {
                viewModel.shareResult()
                true
            }
            R.id.action_refresh -> {
                viewModel.refreshAnalysis()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    companion object {
        const val EXTRA_ANALYSIS_ID = "extra_analysis_id"
        const val EXTRA_SYMBOL = "extra_symbol"
        const val EXTRA_NAME = "extra_name"
    }
}
