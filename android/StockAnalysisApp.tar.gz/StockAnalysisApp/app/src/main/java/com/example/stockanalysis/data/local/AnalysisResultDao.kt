package com.example.stockanalysis.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.stockanalysis.data.model.AnalysisResult

/**
 * 分析结果 DAO
 */
@Dao
interface AnalysisResultDao {
    
    @Query("SELECT * FROM analysis_results ORDER BY analysisTime DESC")
    fun getAllResults(): LiveData<List<AnalysisResult>>
    
    @Query("SELECT * FROM analysis_results ORDER BY analysisTime DESC")
    suspend fun getAllResultsSync(): List<AnalysisResult>
    
    @Query("SELECT * FROM analysis_results WHERE stockSymbol = :symbol ORDER BY analysisTime DESC")
    fun getResultsBySymbol(symbol: String): LiveData<List<AnalysisResult>>
    
    @Query("SELECT * FROM analysis_results WHERE stockSymbol = :symbol ORDER BY analysisTime DESC LIMIT 1")
    suspend fun getLatestResultBySymbol(symbol: String): AnalysisResult?
    
    @Query("SELECT * FROM analysis_results WHERE id = :id LIMIT 1")
    suspend fun getResultById(id: String): AnalysisResult?
    
    @Query("SELECT * FROM analysis_results WHERE isSynced = 0")
    suspend fun getUnsyncedResults(): List<AnalysisResult>
    
    @Query("SELECT COUNT(*) FROM analysis_results")
    suspend fun getResultCount(): Int
    
    @Query("SELECT COUNT(*) FROM analysis_results WHERE stockSymbol = :symbol")
    suspend fun getResultCountBySymbol(symbol: String): Int
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResult(result: AnalysisResult)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResults(results: List<AnalysisResult>)
    
    @Update
    suspend fun updateResult(result: AnalysisResult)
    
    @Delete
    suspend fun deleteResult(result: AnalysisResult)
    
    @Query("DELETE FROM analysis_results WHERE id = :id")
    suspend fun deleteResultById(id: String)
    
    @Query("DELETE FROM analysis_results WHERE stockSymbol = :symbol")
    suspend fun deleteResultsBySymbol(symbol: String)
    
    @Query("DELETE FROM analysis_results")
    suspend fun deleteAllResults()
    
    @Query("UPDATE analysis_results SET isSynced = 1 WHERE id = :id")
    suspend fun markAsSynced(id: String)
    
    @Query("UPDATE analysis_results SET isNotified = 1 WHERE id = :id")
    suspend fun markAsNotified(id: String)
    
    @Query("""
        SELECT * FROM analysis_results 
        WHERE analysisTime >= :startTime AND analysisTime <= :endTime 
        ORDER BY analysisTime DESC
    """)
    suspend fun getResultsByTimeRange(startTime: Long, endTime: Long): List<AnalysisResult>
    
    @Query("""
        SELECT decision, COUNT(*) as count FROM analysis_results 
        GROUP BY decision
    """)
    suspend fun getDecisionStatistics(): Map<String, Int>
}
