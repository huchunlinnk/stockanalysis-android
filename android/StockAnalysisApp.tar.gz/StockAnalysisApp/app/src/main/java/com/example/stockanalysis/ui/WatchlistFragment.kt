package com.example.stockanalysis.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.stockanalysis.R
import com.example.stockanalysis.data.model.MarketType
import com.example.stockanalysis.data.model.Stock
import com.example.stockanalysis.data.model.StockQuote
import com.example.stockanalysis.databinding.FragmentWatchlistBinding
import com.example.stockanalysis.ui.viewmodel.WatchlistViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * 自选Fragment
 * 显示股票列表，支持添加、删除、刷新
 */
@AndroidEntryPoint
class WatchlistFragment : Fragment() {

    private var _binding: FragmentWatchlistBinding? = null
    private val binding get() = _binding!!
    private val viewModel: WatchlistViewModel by activityViewModels()

    private lateinit var stockAdapter: WatchlistAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentWatchlistBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initViews()
        observeViewModel()
    }

    private fun initViews() {
        // 初始化RecyclerView
        stockAdapter = WatchlistAdapter(
            onItemClick = { stock ->
                (activity as? MainActivity)?.openStockDetail(stock.symbol, stock.name)
            },
            onAnalyzeClick = { stock ->
                viewModel.analyzeStock(stock)
            }
        )

        binding.rvWatchlist.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = stockAdapter
        }

        // 添加滑动删除功能
        val itemTouchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean = false

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.adapterPosition
                val stock = stockAdapter.getItemAt(position)
                showDeleteConfirmDialog(stock)
            }
        })
        itemTouchHelper.attachToRecyclerView(binding.rvWatchlist)

        // 添加按钮
        binding.fabAddStock.setOnClickListener {
            showAddStockDialog()
        }

        // 刷新按钮
        binding.btnRefresh.setOnClickListener {
            viewModel.refreshQuotes()
        }
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.watchlist.collectLatest { stocks ->
                        stockAdapter.submitList(stocks)
                        binding.tvEmpty.visibility = 
                            if (stocks.isEmpty()) View.VISIBLE else View.GONE
                    }
                }

                launch {
                    viewModel.quotes.collectLatest { quotes ->
                        stockAdapter.updateQuotes(quotes)
                    }
                }

                launch {
                    viewModel.isLoading.collectLatest { isLoading ->
                        binding.swipeRefresh.isRefreshing = isLoading
                    }
                }

                launch {
                    viewModel.errorMessage.collectLatest { error ->
                        error?.let {
                            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
                        }
                    }
                }

                launch {
                    viewModel.analysisEvent.collectLatest { event ->
                        when (event) {
                            is WatchlistViewModel.AnalysisEvent.Success -> {
                                (activity as? MainActivity)?.openAnalysisResult(event.analysisId)
                            }
                            is WatchlistViewModel.AnalysisEvent.Error -> {
                                Toast.makeText(context, event.message, Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            }
        }

        // 下拉刷新
        binding.swipeRefresh.setOnRefreshListener {
            viewModel.refreshQuotes()
        }
    }

    /**
     * 显示添加股票对话框
     */
    private fun showAddStockDialog() {
        val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_add_stock, null)
        val etSymbol = dialogView.findViewById<EditText>(R.id.etSymbol)
        val etName = dialogView.findViewById<EditText>(R.id.etName)

        AlertDialog.Builder(context)
            .setTitle("添加股票")
            .setView(dialogView)
            .setPositiveButton("添加") { _, _ ->
                val symbol = etSymbol.text.toString().trim()
                val name = etName.text.toString().trim()
                if (symbol.isNotEmpty() && name.isNotEmpty()) {
                    val stock = Stock(
                        symbol = symbol,
                        name = name,
                        market = MarketType.A_SHARE
                    )
                    viewModel.addStock(stock)
                } else {
                    Toast.makeText(context, "请输入股票代码和名称", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    /**
     * 显示删除确认对话框
     */
    private fun showDeleteConfirmDialog(stock: Stock) {
        AlertDialog.Builder(context)
            .setTitle("删除自选")
            .setMessage("确定要删除 ${stock.name}(${stock.symbol}) 吗？")
            .setPositiveButton("删除") { _, _ ->
                viewModel.removeStock(stock.symbol)
            }
            .setNegativeButton("取消") { _, _ ->
                stockAdapter.notifyDataSetChanged()
            }
            .setOnCancelListener {
                stockAdapter.notifyDataSetChanged()
            }
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

/**
 * 自选股票适配器
 */
class WatchlistAdapter(
    private val onItemClick: (Stock) -> Unit,
    private val onAnalyzeClick: (Stock) -> Unit
) : RecyclerView.Adapter<WatchlistAdapter.ViewHolder>() {

    private var stocks: List<Stock> = emptyList()
    private var quotes: Map<String, StockQuote> = emptyMap()

    fun submitList(newStocks: List<Stock>) {
        stocks = newStocks
        notifyDataSetChanged()
    }

    fun updateQuotes(newQuotes: Map<String, StockQuote>) {
        quotes = newQuotes
        notifyDataSetChanged()
    }

    fun getItemAt(position: Int): Stock = stocks[position]

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = com.example.stockanalysis.databinding.ItemWatchlistStockBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val stock = stocks[position]
        val quote = quotes[stock.symbol]
        holder.bind(stock, quote)
    }

    override fun getItemCount(): Int = stocks.size

    inner class ViewHolder(
        private val binding: com.example.stockanalysis.databinding.ItemWatchlistStockBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(stock: Stock, quote: StockQuote?) {
            binding.tvStockName.text = stock.name
            binding.tvStockSymbol.text = stock.symbol

            if (quote != null) {
                binding.tvPrice.text = quote.getPriceText()
                binding.tvChange.text = quote.getChangePercentText()
                
                val colorRes = when {
                    quote.change > 0 -> android.R.color.holo_red_dark
                    quote.change < 0 -> android.R.color.holo_green_dark
                    else -> android.R.color.darker_gray
                }
                binding.tvChange.setTextColor(binding.root.context.getColor(colorRes))
                binding.tvPrice.visibility = View.VISIBLE
                binding.tvChange.visibility = View.VISIBLE
            } else {
                binding.tvPrice.visibility = View.GONE
                binding.tvChange.visibility = View.GONE
            }

            binding.root.setOnClickListener { onItemClick(stock) }
            binding.btnAnalyze.setOnClickListener { onAnalyzeClick(stock) }
        }
    }
}
