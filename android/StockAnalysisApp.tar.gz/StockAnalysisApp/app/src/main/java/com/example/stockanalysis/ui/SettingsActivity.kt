package com.example.stockanalysis.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.MenuItem
import android.widget.EditText
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.stockanalysis.databinding.ActivitySettingsBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * 设置页面
 * 包含API配置、通知设置、数据管理等
 */
@AndroidEntryPoint
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private val viewModel: SettingsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initViews()
        observeViewModel()
        viewModel.loadSettings()
    }

    private fun initViews() {
        // 设置Toolbar
        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            title = "设置"
        }

        // API Key 设置
        binding.btnSetApiKey.setOnClickListener {
            showApiKeyDialog()
        }

        // API Base URL 设置
        binding.btnSetApiUrl.setOnClickListener {
            showApiUrlDialog()
        }

        // API Model 设置
        binding.btnSetApiModel.setOnClickListener {
            showApiModelDialog()
        }

        // 通知设置
        binding.switchAnalysisNotification.setOnCheckedChangeListener { _, isChecked ->
            viewModel.setAnalysisNotification(isChecked)
        }

        binding.switchMarketNotification.setOnCheckedChangeListener { _, isChecked ->
            viewModel.setMarketNotification(isChecked)
        }

        binding.switchDailyReport.setOnCheckedChangeListener { _, isChecked ->
            viewModel.setDailyReport(isChecked)
        }

        // 数据管理
        binding.btnClearCache.setOnClickListener {
            showClearCacheConfirmDialog()
        }

        binding.btnClearHistory.setOnClickListener {
            showClearHistoryConfirmDialog()
        }

        binding.btnExportData.setOnClickListener {
            viewModel.exportData()
        }

        binding.btnImportData.setOnClickListener {
            // 打开文件选择器
            openFilePicker()
        }

        // 关于
        binding.btnCheckUpdate.setOnClickListener {
            viewModel.checkUpdate()
        }

        binding.btnPrivacyPolicy.setOnClickListener {
            openPrivacyPolicy()
        }

        binding.btnTermsOfService.setOnClickListener {
            openTermsOfService()
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.settings.collectLatest { settings ->
                        settings?.let { updateUI(it) }
                    }
                }

                launch {
                    viewModel.isLoading.collectLatest { isLoading ->
                        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
                    }
                }

                launch {
                    viewModel.message.collectLatest { message ->
                        message?.let {
                            Toast.makeText(this@SettingsActivity, it, Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
    }

    private fun updateUI(settings: com.example.stockanalysis.data.model.Settings) {
        // API设置
        binding.tvApiKeyStatus.text = if (settings.llmApiKey.isNotEmpty()) "已设置" else "未设置"
        binding.tvApiUrlStatus.text = settings.llmBaseUrl.ifEmpty { "默认" }
        binding.tvApiModelStatus.text = settings.llmModel.ifEmpty { "gpt-3.5-turbo" }

        // 通知设置
        binding.switchAnalysisNotification.isChecked = settings.analysisNotification
        binding.switchMarketNotification.isChecked = settings.marketNotification
        binding.switchDailyReport.isChecked = settings.dailyReport

        // 版本信息
        binding.tvVersion.text = "版本: ${getAppVersion()}"
    }

    private fun showApiKeyDialog() {
        val editText = EditText(this).apply {
            hint = "请输入API Key"
            setText(viewModel.settings.value?.llmApiKey ?: "")
        }

        AlertDialog.Builder(this)
            .setTitle("设置API Key")
            .setView(editText)
            .setPositiveButton("确定") { _, _ ->
                val apiKey = editText.text.toString().trim()
                viewModel.setApiKey(apiKey)
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showApiUrlDialog() {
        val editText = EditText(this).apply {
            hint = "请输入API Base URL"
            setText(viewModel.settings.value?.llmBaseUrl ?: "")
        }

        AlertDialog.Builder(this)
            .setTitle("设置API URL")
            .setView(editText)
            .setPositiveButton("确定") { _, _ ->
                val url = editText.text.toString().trim()
                viewModel.setApiUrl(url)
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showApiModelDialog() {
        val models = arrayOf("gpt-3.5-turbo", "gpt-4", "gpt-4-turbo", "claude-3-opus", "claude-3-sonnet")
        
        AlertDialog.Builder(this)
            .setTitle("选择模型")
            .setItems(models) { _, which ->
                viewModel.setApiModel(models[which])
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showClearCacheConfirmDialog() {
        AlertDialog.Builder(this)
            .setTitle("清除缓存")
            .setMessage("确定要清除所有缓存数据吗？")
            .setPositiveButton("确定") { _, _ ->
                viewModel.clearCache()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showClearHistoryConfirmDialog() {
        AlertDialog.Builder(this)
            .setTitle("清除历史")
            .setMessage("确定要清除所有分析历史吗？此操作不可撤销。")
            .setPositiveButton("确定") { _, _ ->
                viewModel.clearHistory()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun openFilePicker() {
        // 简化实现，实际应该使用Activity Result API
        Toast.makeText(this, "导入功能待实现", Toast.LENGTH_SHORT).show()
    }

    private fun openPrivacyPolicy() {
        // 打开隐私政策页面
        Toast.makeText(this, "隐私政策", Toast.LENGTH_SHORT).show()
    }

    private fun openTermsOfService() {
        // 打开服务条款页面
        Toast.makeText(this, "服务条款", Toast.LENGTH_SHORT).show()
    }

    private fun getAppVersion(): String {
        return try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0.0"
        } catch (e: Exception) {
            "1.0.0"
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}

/**
 * 设置ViewModel
 */
@dagger.hilt.android.lifecycle.HiltViewModel
class SettingsViewModel @javax.inject.Inject constructor(
    private val settingsManager: com.example.stockanalysis.utils.SettingsManager,
    private val analysisRepository: com.example.stockanalysis.data.repository.AnalysisRepository
) : androidx.lifecycle.ViewModel() {

    private val _settings = kotlinx.coroutines.flow.MutableStateFlow<com.example.stockanalysis.data.model.Settings?>(null)
    val settings: kotlinx.coroutines.flow.StateFlow<com.example.stockanalysis.data.model.Settings?> = _settings

    private val _isLoading = kotlinx.coroutines.flow.MutableStateFlow(false)
    val isLoading: kotlinx.coroutines.flow.StateFlow<Boolean> = _isLoading

    private val _message = kotlinx.coroutines.flow.MutableStateFlow<String?>(null)
    val message: kotlinx.coroutines.flow.StateFlow<String?> = _message

    fun loadSettings() {
        viewModelScope.launch {
            _settings.value = settingsManager.getSettings()
        }
    }

    fun setApiKey(apiKey: String) {
        viewModelScope.launch {
            settingsManager.setApiKey(apiKey)
            loadSettings()
            _message.value = "API Key 已保存"
        }
    }

    fun setApiUrl(url: String) {
        viewModelScope.launch {
            settingsManager.setApiBaseUrl(url)
            loadSettings()
            _message.value = "API URL 已保存"
        }
    }

    fun setApiModel(model: String) {
        viewModelScope.launch {
            settingsManager.setModel(model)
            loadSettings()
            _message.value = "模型已设置为 $model"
        }
    }

    fun setAnalysisNotification(enabled: Boolean) {
        viewModelScope.launch {
            settingsManager.setAnalysisNotification(enabled)
            loadSettings()
        }
    }

    fun setMarketNotification(enabled: Boolean) {
        viewModelScope.launch {
            settingsManager.setMarketNotification(enabled)
            loadSettings()
        }
    }

    fun setDailyReport(enabled: Boolean) {
        viewModelScope.launch {
            settingsManager.setDailyReport(enabled)
            loadSettings()
        }
    }

    fun clearCache() {
        viewModelScope.launch {
            _isLoading.value = true
            // 清除缓存逻辑
            _isLoading.value = false
            _message.value = "缓存已清除"
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            _isLoading.value = true
            analysisRepository.clearHistory()
            _isLoading.value = false
            _message.value = "历史记录已清除"
        }
    }

    fun exportData() {
        viewModelScope.launch {
            _isLoading.value = true
            // 导出数据逻辑
            _isLoading.value = false
            _message.value = "数据导出成功"
        }
    }

    fun checkUpdate() {
        viewModelScope.launch {
            _message.value = "已是最新版本"
        }
    }
}
